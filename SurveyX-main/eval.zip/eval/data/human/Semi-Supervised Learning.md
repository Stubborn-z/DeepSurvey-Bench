# A Survey on Deep Semi-supervised Learning  

Xiangli Yang, Zixing Song, Irwin King, Fellow, IEEE, Zenglin Xu, Senior Member, IEEE  

Abstract—Deep semi-supervised learning is a fast-growing field with a range of practical applications. This paper provides a comprehensive survey on both fundamentals and recent advances in deep semi-supervised learning methods from perspectives of model design and unsupervised loss functions. We first present a taxonomy for deep semi-supervised learning that categorizes existing methods, including deep generative methods, consistency regularization methods, graph-based methods, pseudo-labeling methods, and hybrid methods. Then we provide a comprehensive review of 52 representative methods and offer a detailed comparison of these methods in terms of the type of losses, contributions, and architecture differences. In addition to the progress in the past few years, we further discuss some shortcomings of existing methods and provide some tentative heuristic solutions for solving these open problems.  

Terms—Deep semi-supervised learning, image classification, machine learning,  

# INTRODUCTION  

EEP learning has been an active research field with D abundant applications in pattern recognition [1], [2], data mining [3], statistical learning [4], computer vision [5], [6], natural language processing [7], [8], etc. It has achieved great successes in both theory and practice [9], [10], especially in supervised learning scenarios, by leveraging a large amount of high-quality labeled data. However, labeled samples are often difficult, expensive, or time-consuming to obtain. The labeling process usually requires experts’ efforts, which is one of the major limitations to train an excellent fully-supervised deep neural network. For example, in medical tasks, the measurements are made with expensive machinery, and labels are drawn from a time-consuming analysis of multiple human experts. If only a few labeled samples are available, it is challenging to build a successful learning system. By contrast, the unlabeled data is usually abundant and can be easily or inexpensively obtained. Consequently, it is desirable to leverage a large number of unlabeled data for improving the learning performance given a small number of labeled samples. For this reason, semi-supervised learning (SSL) has been a hot research topic in machine learning in the last decade [11], [12].  

SSL is a learning paradigm associated with constructing models that use both labeled and unlabeled data. SSL methods can improve learning performance by using additional unlabeled instances compared to supervised learning algorithms, which can use only labeled data. It is easy to obtain SSL algorithms by extending supervised learning algorithms or unsupervised learning algorithms. SSL algorithms provide a way to explore the latent patterns from unlabeled examples, alleviating the need for a large number of labels [13]. Depending on the key objective function of the systems, one may have a semi-supervised classification, a semi-supervised clustering, or a semi-supervised regression. We provide the definitions as follows:  

Semi-supervised classification. Given a training dataset that consists of both labeled instances and unlabeled instances, semi-supervised classification aims to train a classifier from both the labeled and unlabeled data, such that it is better than the supervised classifier trained only on the labeled data. Semi-supervised clustering. Given a training dataset that consists of unlabeled instances, and some supervised information about the clusters, the goal of semi-supervised clustering is to obtain better clustering than the clustering from unlabeled data alone. Semi-supervised clustering is also known as constrained clustering.   
Semi-supervised regression. Given a training dataset that consists of both labeled instances and unlabeled instances, the goal of semi-supervised regression is to improve the performance of a regression algorithm from a regression algorithm with labeled data alone, which predicts a real-valued output instead of a class label.  

In order to explain SSL clearly and concretely, we focus on the problem of image classification. The ideas described in this survey can be adapted without difficulty to other situations, such as object detection, semantic segmentation, clustering, or regression. Therefore, we primarily review image classification methods with the aid of unlabeled data in this survey.  

Since the 1970s when the concept of SSL first came to the fore [14], [15], [16], there have been a wide variety of SSL methods, including generative models [17], [18], semisupervised support vector machines [19], [20], [21], [22], graph-based methods [23], [24], [25], [26], and co-training [27]. We refer interested readers to [12], [28], which provide a comprehensive overview of traditional SSL methods. Nowadays, deep neural networks have played a dominating role in many research areas. It is important to adopt the classic SSL framework and develop novel SSL methods for deep learning settings, which leads to deep semisupervised learning (DSSL). DSSL studies how to effectively utilize both labeled and unlabeled data by deep neural networks. A considerable amount of DSSL methods have been proposed. According to the most distinctive features in semi-supervised loss functions and model designs, we classify DSSL into five categories, i.e., generative methods, consistency regularization methods, graph-based methods, pseudo-labeling methods, and hybrid methods. The overall taxonomy used in this literature is shown in Fig. 1.  

![](images/4bd30fcedd493eb66544c68eb24b7b753d69591b97539956f0d5b9cd05d46e51.jpg)  
Fig. 1. The taxonomy of major deep semi-supervised learning methods based on loss function and model design.  

Some representative works of SSL were described in the early survey [12], [28], however, emerging technologies based on deep learning, such as adversarial training which generates new training data for SSL, have not been included. Besides, [13] focuses on unifying the evaluation indices of SSL, and [29] only reviews generative models and teacherstudent models in SSL without making a comprehensive overview of SSL. Although [30] tries to present a whole picture of ${\mathrm{SSL}},$ the taxonomy is quite different from ours. A recent review by Ouali et al. [31] gives a similar notion of DSSL as we do. However, it does not compare the presented methods based on their taxonomy and provide perspectives on future trends and existing issues. Summarizing both previous and the latest research on ${\mathrm{SSL}},$ we survey the fundamental theories and compare the deep semi-supervised methods. In summary, our contributions are listed as follows.  

We provide a detailed review of DSSL methods and introduce a taxonomy of major DSSL methods, background knowledge, and various models. One can quickly grasp the frontier ideas of DSSL. We categorize DSSL methods into several categories, i.e., generative methods, consistency regularization methods, graph-based methods, pseudolabeling methods, and hybrid methods, with particular genres inside each one. We review the variants on each category and give standardized descriptions and unified sketch maps. We identify several open problems in this field and discuss the future direction for DSSL.  

This survey is organized as follows. In Section 2, we introduce SSL background knowledge, including assumptions in SSL, classical SSL methods, related concepts, and datasets used in various applications. Section 4 to Section 7 introduce the primary deep semi-supervised techniques, i.e., generative methods in Section 3, consistency regularization methods in Section $^{4,}$ graph-based methods in Section 5, pseudo-labeling methods in Section 6 and hybrid methods in Section 7. In Section 8, we discuss the challenges in semisupervised learning and provide some heuristic solutions and future directions for these open problems.  

# 2 BACKGROUND  

Before presenting an overview of the techniques of ${\mathrm{SSL}},$ we first introduce the notations. To illustrate the DSSL framework, we limit our focus on the single-label classification tasks which are simple to describe and implement. We refer interested readers to [32], [33], [34] for multi-label classification tasks. Let $X=\{X_{L},X_{U}\}$ denote the entire data set, including a small labeled subset $X_{L}=\{x_{i}\}_{i=1}^{L}$ with labels $Y_{L}~=~(\dot{y}_{1},y_{2},.~.~.~,y_{L})$ and a large scale unlabeled subset $X_{U}~=~\{(x_{i})\}_{i=1}^{U},$ and generally we assume $L\,\ll\,U$ . We assume that the dataset contains $K$ classes and the first $L$ examples within $X$ are labeled by $\{y_{i}\}_{i=1}^{L}\in(y^{1},y^{2},\ldots,y^{K})$ . Formally, SSL aims to solve the following optimization problem,  

![](images/56333686dabf991742d9796e25b5851fee5a2801b1efb26424ed8928c9ba48bf.jpg)  

where $\mathcal{L}_{s}$ denotes the per-example supervised loss, e.g., cross-entropy for classification, $\mathcal{L}_{u}$ denotes the per-example unsupervised loss, and $\mathcal{R}$ denotes the per-example regularization, e.g., consistency loss or a designed regularization term. Note that unsupervised loss terms are often not strictly distinguished from regularization terms, as regularization terms are normally not guided by label information. Lastly, $\theta$ denotes the model parameters and $\alpha,\beta\,\in\,\mathbb{R}_{>0}$ denotes the trade-off. Different choices of the unsupervised loss functions and regularization terms lead to different semisupervised models. Note that we do not make a clear distinction between unsupervised loss and regularization terms in many cases. Unless particularly specified, the notations used in this paper are illustrated in TABLE 1.  

Regarding whether test data are wholly available in the training process, semi-supervised learning can be classified into two settings: the transductive setting and the inductive learning setting. Transductive learning assumes that the unlabeled samples in the training process are exactly the data to be predicted, and the purpose of the transductive learning is to generalize over these unlabeled samples, while inductive learning supposes that the learned semisupervised classifier will be still applicable to new unseen data. In fact, most graph-based methods are transductive while most other kinds of SSL methods are inductive.  

# 2.1 Assumptions for semi-supervised learning  

SSL aims to predict more accurately with the aid of unlabeled data than supervised learning that uses only labeled data. However, an essential prerequisite is that the data distribution should be under some assumptions. Otherwise, SSL may not improve supervised learning and may even degrade the prediction accuracy by misleading inferences. Following [12] and [28], the related assumptions in SSL include:  

Self-training assumption. The predictions of the selftraining model, especially those with high confidence, tend to be correct. We can assume that when the hypothesis is satisfied, those high-confidence predictions are considered to be ground-truth. This can happen when classes form wellseparated clusters.  

Co-training assumption. Different reasonable assumptions lead to different combinations of labeled and unlabeled data, and accordingly, different algorithms are designed to take advantage of these combinations. For example, Blum et al. [27] proposed a co-training model, which works under the assumptions: instance $x$ has two conditionally independent views, and each view is sufficient for a classification task.  

Generative model assumption. Generally, it is assumed that data are generated from a mixture of distributions. When the number of mixed components, a prior $p(y)$ and a conditional distribution $p(x|y)$ are correct, data can be assumed to come from the mixed model. This assumption suggests that if the generative model is correct enough, we can establish a valid link between the distribution of unlabeled data and the category labels by $p(x,y)=p(y)p(x|y)$ .  

Cluster assumption. If two points $x_{1}$ and $x_{2}$ are in the same cluster, they should belong to the same category [28]. This assumption refers to the fact that data in a single class tend to form a cluster, and when the data points can be connected by short curves that do not pass through any lowdensity regions, they belong to the same class cluster [28]. According to this assumption, the decision boundary should not cross high-density areas but instead lie in low-density regions [35]. Therefore, the learning algorithm can use a large amount of unlabeled data to adjust the classification boundary.  

Low-density separation. The decision boundary should be in a low-density region, not through a high-density area [28]. The low-density separation assumption is closely related to the cluster assumption. We can consider the clustering assumption from another perspective by assuming that the class is separated by areas of low density [28]. Since the decision boundary in a high-density region would cut a cluster into two different classes and within such a part would violate the cluster assumption.  

TABLE 1 Notations   


<html><body><table><tr><td>Symbol</td><td>Explanation</td></tr><tr><td>七</td><td>Input space,for exampleX=Rn</td></tr><tr><td></td><td>Output space.</td></tr><tr><td></td><td>Classification: ↓ = {y, y²,</td></tr><tr><td></td><td>Regression: J = R</td></tr><tr><td>XL Xu</td><td>Labeled dataset.E X,yi E J</td></tr><tr><td>X</td><td>Unlabeled dataset. c E X</td></tr><tr><td>C</td><td>》T+=N'X aseep 4ndu</td></tr><tr><td>G</td><td>Loss Function</td></tr><tr><td>D</td><td>Generator</td></tr><tr><td>C</td><td>Discriminator</td></tr><tr><td>H</td><td>Classifier</td></tr><tr><td>E</td><td>Entropy</td></tr><tr><td>R</td><td>Expectation</td></tr><tr><td>Tr</td><td>Consistency constraint Consistency target</td></tr><tr><td>g</td><td>A graph</td></tr><tr><td>V</td><td>The set of vertices in a graph</td></tr><tr><td></td><td></td></tr><tr><td>U</td><td>The set of edges in a graph AnodevEV</td></tr><tr><td>eij</td><td></td></tr><tr><td>A</td><td>An edge linked between node i and j, eij E &</td></tr><tr><td>D</td><td>The adjacency matrix of a graph</td></tr><tr><td>Dii</td><td>The degree matrix of a graph</td></tr><tr><td>M</td><td>The degree of node i</td></tr><tr><td>Wij.</td><td>The weight matrix</td></tr><tr><td>N(v)</td><td>The weight associated with edge eij The neighbors of a node v</td></tr><tr><td>Z</td><td></td></tr><tr><td>Z</td><td>Embedding matrix An embedding for node v</td></tr><tr><td>S</td><td>Similarity matrix of a graph</td></tr><tr><td>S[u,]</td><td>Similarity measurement between node u and v</td></tr><tr><td></td><td></td></tr><tr><td>mN()</td><td>Hidden embedding for node v in kth layer Message aggregated from node v's neighborhoods</td></tr></table></body></html>  

Manifold assumption. If two points $x_{1}$ and $x_{2}$ are located in a local neighborhood in the low-dimensional manifold, they have similar class labels [28]. This assumption reflects the local smoothness of the decision boundary. It is well known that one of the problems of machine learning algorithms is the curse of dimensionality. It is hard to estimate the actual data distribution when volume grows exponentially with the dimensions in high dimensional spaces. If the data lie on a low-dimensional manifold, the learning algorithms can avoid the curse of dimensionality and operate in the corresponding low-dimension space.  

# 2.2 Classical Semi-supervised learning Methods  

In the following, we briefly introduce some representative SSL methods motivated from the above described assumptions.  

In the 1970s, the concept of SSL first came to the fore [14], [15], [16]. Perhaps the earliest method has been established as self-learning — an iterative mechanism that uses initial labeled data to train a model to predict some unlabeled samples. Then the most confident prediction is marked as the best prediction of the current supervised model, thus providing more training data for the supervised algorithm, until all the unlabelled examples have been predicted.  

Co-training [27] provides a similar solution by training two different models on two different views. Confident predictions of one view are then used as labels for the other model. More relevant literature of this method also includes [36], [37], [38], etc.  

Generative models assume a model $\begin{array}{r l}{p(x,y)}&{{}=}\end{array}$ $p(y)p(x|y).$ , where the density function $p(x|y)$ is an identifiable distribution, for example, polynomial, Gaussian mixture distribution, etc., and the uncertainty is the parameters of $p(x|y)$ . Generative models can be optimized by using iterative algorithms. [17], [18] apply EM algorithm for classification. They compute the parameters of $p(x|y)$ and then classify unlabeled instances according to the Bayesian full probability formula. Moreover, generative models are harsh on some assumptions. Once the hypothetical $p(x|y)$ is poorly matched with the actual distribution, it can lead to classifier performance degradation.  

A representative example following the low-density separation principle is Transductive Support Vector Machines (TSVMs) [19], [20], [35], [39], [40]. As regular SVMs, TSVMs optimize the gap between decision boundaries and data points, and then expand this gap based on the distance from unlabeled data to the decision margin. To address the corresponding non-convex optimization problem, a number of optimization algorithms have been proposed. For instance, in [35], a smooth loss function substitutes the hinge loss of the TSVM, and for the decision boundary in a low-density space, a gradient descent technique may be used.  

Graph-based methods rely on the geometry of the data induced by both labeled and unlabeled examples. This geometry is represented by an empirical graph $\bar{\mathcal{G}}=(\mathcal{V},\mathcal{E})$ , where nodes $\nu$ represent the training data points with $|\nu|~=~n$ and edges $\mathcal{E}$ represent similarities between the points. By exploiting the graph or manifold structure of data, it is possible to learn with very few labels to propagate information through the graph [23], [24], [25], [26], [41], [42]. For example, Label propagation [41] is to predict the label information of unlabeled nodes from labeled nodes. Each node label propagates to its neighbors according to the similarity.At each step of node propagation, each node updates its label according to its neighbors’ label information. In the label propagation label, the label of the labeled data is fixed so that it propagates the label to the unlabeled data. The label propagation method can be applied to deep learning [43].  

# 2.3 Related Learning Paradigms  

There are many learning paradigms that can make use of an extra data source to boost learning performance. Based on the availability of labels or the distribution difference in the extra data source, there are several learning paradigms related to semi-supervised learning.  

Transfer learning. Transfer learning [44], [45], [46] aims to apply knowledge from one or more source domains to a target domain in order to improve performance on the target task. In contrast to SSL, which works well under the hypothesis that the training set and the testing set are independent and identically distributed (i.i.d.), transfer learning allows domains, tasks, and distributions used in training and testing be different but related.  

Weakly-supervised learning. Weakly-supervised learning [47] relaxes the data dependence that requires groundtruth labels to be given for a large amount of training data set in strong supervision. There are three types of weakly supervised data: incomplete supervised data, inexact supervised data, and inaccurate supervised data. Incomplete supervised data means only a subset of training data is labeled. In this case, representative approaches are SSL and domain adaptation. Inexact supervised data suggests that the labels of training examples are coarse-grained, e.g., in the scenario of multi-instance learning. Inaccurate supervised data means that the given labels are not always groundtruth, such as in the situation of label noise learning.  

Positive and unlabeled learning. Positive and unlabeled (PU) learning [48], [49] is a variant of positive and negative binary classification, where the training data consists of positive samples and unlabeled samples. Each unlabeled instance can be either the positive and negative class. During the training procedure, only positive samples and unlabeled samples are available. We can think of PU learning as a special case of SSL.  

Meta-learning. Meta-learning [50], [51], [52], [53], [54], also known as “learning to learn”, aims to learn new skills or adapt to new tasks rapidly with previous knowledge and a few training examples. It is well known that a good machine learning model often requires a large number of samples for training. The meta-learning model is expected to adapt and generalize to new environments that have been encountered during the training process. The adaptation process is essentially a mini learning session that occurs during the test but has limited exposure to new task configurations. Eventually, the adapted model can be trained on various learning tasks and optimized on the distribution of functions, including potentially unseen tasks.  

Self-supervised learning. Self-supervised learning [55], [56], [57] has gained popularity due to its ability to prevent the expense of annotating large-scale datasets. It can leverage input data as supervision and use the learned feature representations for many downstream tasks. In this sense, self-supervised learning meets our expectations for efficient learning systems with fewer labels, fewer samples, or fewer trials. Since there is no manual label involved, self-supervised learning can be regarded as a branch of unsupervised learning.  

# 2.4 Datasets and applications  

SSL has many applications across different tasks and domains, such as image classification, object detection, semantic segmentation, etc. in the domain of computer vision, and text classification, sequence learning, etc. in the field of Natural Language Processing (NLP). As shown in TABLE 2, we summarize some of the most widely used datasets and representative references according to the applications area. In this survey, we mainly discuss the methods applied to image classification since these methods can be extended to other applications, such as [58] applied consistency training to object detection, [59] modified Semi-GANs to fit the scenario of semantic segmentation. There are many works that have achieved state-of-the-art performance within different applications. Most of these methods share details of the implementation and source code, and we refer the interested readers to a more detailed review of the datasets and corresponding references in TABLE 2.  

TABLE 2 Summary of Applications and Datasets   


<html><body><table><tr><td>Applications</td><td>Datasets</td><td>Citations</td></tr><tr><td>Image classification</td><td>MNIST [60], SVHN [61], STL-10 [62], Cifar-10,Cifar-100 [63], ImageNet</td><td>[65], [66], [67], [68],</td></tr><tr><td>Objectdetection</td><td>[64] PASCAL VOC[74], MSCOCO[75], ILSVRC[76]</td><td>[69],[70], [71],[72],[73] [58],[77],[78],[79]</td></tr><tr><td>3Dobjectdetection</td><td>SUN RGB-D [80], ScanNet [81],KITTI[82]</td><td>[83], [84]</td></tr><tr><td>Videosalientobject detection</td><td>VOS[85],DAVIS[86],FBMS[87]</td><td>[88]</td></tr><tr><td>Semanticsegmentation</td><td>PASCALVOC[74],PASCALcontext[89],MSCOCO[75],Cityscapes [90],CamVid [91], SiftFlow [92],[93],StanfordBG[94]</td><td>[59], [95], [96], [97], [98],[99],[100],[101] [102],[103]</td></tr><tr><td>Text classification</td><td>AG News [104], BPpedia [105], Yahoo! Answers [106], IMDB [107], Yelp review [104], Snippets [108], Ohsumed [109], TagMyNews [110], MR</td><td>[114], [115], [116], [117], [118], [119]</td></tr><tr><td>Dialoguepolicylearning</td><td>[111],Elec[112],RottenTomatoes[111],RCV1[113] MultiWOZ[120]</td><td>[121]</td></tr><tr><td>Dialogue generation</td><td>Cornell Movie Dialogs Corpus [122], Ubuntu Dialogue Corpus [123]</td><td>[124]</td></tr><tr><td>Sequence learning</td><td>IMDB [107], Rotten Tomatoes [111], 20 Newsgroups [125], DBpedia [105], CoNLL 2003 NER task [126],CoNLL 2000 Chunking task [127], Twitter POS Dataset [128], [129], Universal Dependencies(UD)[130],</td><td>[132],[133],[134],[135]</td></tr><tr><td>Semanticrole labeling</td><td>Combinatory Categorial Grammar (CCG) supertagging [131] CoNLL-2009[136],CoNLL-2013[137]</td><td>[138],[139],[140]</td></tr><tr><td>Questionanswering</td><td>SQuAD[141],TriviaQA[142]</td><td>[143],[144],[145]</td></tr></table></body></html>  

# 3 GENERATIVE METHODS  

As discussed in Subsection 2.2, generative methods can learn the implicit features of data to better model data distributions. They model the real data distribution from the training dataset and then generate new data with this distribution. In this section, we review the deep generative semi-supervised methods based on the Generative Adversarial Network (GAN) framework and the Variational AutoEncoder (VAE) framework, respectively.  

# 3.1 Semi-supervised GANs  

A typical GAN [146] consists of a generator $G$ and a discriminator $D$ (see Fig. 2(2)). The goal of $G$ is to learn a distribution $p_{g}$ over data $x$ given a prior on input noise variables $p_{z}(z)$ . The fake samples $G(z)$ generated by the generator $G$ are used to confuse the discriminator $D$ . The discriminator $D$ is used to maximize the distinction between real training samples $x$ and fake samples $G(z)$ . As we can see, $D$ and $G$ play the following two-player minimax game with the value function $V(G,D)$ :  

$$
\begin{array}{r}{\underset{G}{\operatorname*{min}}\,\underset{D}{\operatorname*{max}}\,V(D,G)=\mathbb{E}_{x\sim p(x)}[\log D(x)]}\\ {+\mathbb{E}_{z\sim p_{z}}[\log(1-D(G(z)))].}\end{array}
$$  

Since GANs can learn the distribution of real data from unlabeled samples, it can be used to facilitate SSL. There are many ways to use GANs in SSL settings. Inspired by [147], we have identified four main themes in how to use GANs for SSL, i.e., (a) re-using the features from the discriminator, (b) using GAN-generated samples to regularize a classifier, (c) learning an inference model, and (d) using samples produced by a GAN as additional training data.  

A simple SSL approach is to combine supervised and unsupervised loss during training. [148] demonstrates that a hierarchical representation of the GAN-discriminator is useful for object classification. These findings indicate that a simple and efficient SSL method can be provided by combining an unsupervised GAN value function with a supervised classification objective function, e.g., $\mathbb{E}_{(x,y)\in X_{l}}[\log D(y|x)]$ . In the following, we review several representative methods of semi-supervised GANs.  

CatGAN. Categorical Generative Adversarial Network (CatGAN) [149] modifies the GAN’s objective function to take into account the mutual information between observed examples and their predicted categorical class distributions. In particular, the optimization problem is different from the standard GAN (Eq. (2)). The structure is illustrated in Fig. 2(3). This method aims to learn a discriminator which distinguishes the samples into $K$ categories by labeling $y$ to each $x_{.}$ , instead of learning a binary discriminator value function. Moreover, in the CatGAN discriminator loss function, the supervised loss is also a cross-entropy term between the predicted conditional distribution $p(\boldsymbol{\bar{y}}|\boldsymbol{x},D)$ and the true label distribution of examples. It consists of three parts: (1) entropy $H[p(y|x,D)]$ which to obtain certain category assignment for samples; (2) $H[p(y|G(z),D)]$ for uncertain predictions from generated samples; and (3) the marginal class entropy $H[p(y|D)]$ to uniform usage of all classes. The proposed framework uses the feature space learned by the discriminator for the final learning task. For the labeled data, the supervised loss is also a cross-entropy term between the conditional distribution $p(\boldsymbol{y}|\boldsymbol{x},D)$ and the samples’ true label distribution.  

CCGAN. Context-Conditional Generative Adversarial Networks (CCGAN) [150] is proposed to use an adversarial loss for harnessing unlabeled image data based on image in-painting. The architecture of the CCGAN is shown in Fig. 2(4). The main highlight of this work is context information provided by the surrounding parts of the image. The method trains a GAN where the generator is to generate pixels within a missing hole. The discriminator is to discriminate between the real unlabeled images and these in-painted images. More formally, $m\odot x$ as input to a generator, where $m$ denotes a binary mask to drop out a specified portion of an image and $\odot$ denotes element-wise multiplication. Thus the in-painted image $x_{I}\,=\,(1\,-\,m)\odot x_{G}\,+\,m\odot x$ with generator outputs $x_{G}\mathrm{~=~}G(m\odot x,z)$ . The in-painted examples provided by the generator cause the discriminator to learn features that generalize to the related task of classifying objects. The penultimate layer of components of the discriminator is then shared with the classifier, whose cross-entropy loss is used combined with the discriminator loss.  

![](images/2d663ed68854f802cbe4e72e4835f6a28e5ba416724b21857b7d497048f23f56.jpg)  
Fig. 2. A glimpse of the diverse range of architectures used for GAN-based deep generative semi-supervised methods. The characters ‘ $D,G^{*}$ and $E^{\ast}$ represent Discriminator, Generator and Encoder, respectively. In Figure (6), Localized GAN is equipped with a local generator $G(x,z)$ , so we use the yellow box to distinguish it. Similarly, in CT-GAN, the purple box is used to denote a discriminator that introduces consistency constraint.  

Improved GAN. There are several methods to adapt GANs into a semi-supervised classification scenario. CatGAN [149] forces the discriminator to maximize the mutual information between examples and their predicted class distributions instead of training the discriminator to learn a binary classification. To overcome the learned representations’ bottleneck of CatGAN, Semi-supervised GAN (SGAN) [151] learns a generator and a classifier simultaneously. The classifier network can have $(K+1)$ output units corresponding to $[y_{1},y_{2},\dots,y_{K},y_{K+1}],$ where the $y_{K+1}$ represents the outputs generated by $G$ . Similar to SGAN, Improved GAN [152] solves a $(K\!+\!1)$ -class classification problem. The structure of Improved GAN is shown in Fig. 2(5). Real examples for one of the first $K$ classes and the additional $(K+\bar{1})$ th class consisted of the synthetic images generated by the generator $G$ . This work proposes the improved techniques to train the GANs, i.e., feature matching, minibatch discrimination, historical averaging one-sided label smoothing, and virtual batch normalization, where feature matching is used to train the generator. It is trained by minimizing the discrepancy between features of the real and the generated examples, that is $\|\mathbb{E}_{x\in X}D(x)-\mathbb{E}_{z\sim p(z)}D(G(z))\|_{2}^{2},$ rather than maximizing the likelihood of its generated examples classified to $K$ real classes. The loss function for training the classifier becomes  

$$
\begin{array}{r l}{}&{\underset{D}{\operatorname*{max}}\,\mathbb{E}_{(x,y)\sim p(x,y)}\log p_{D}(y|x,y\le K)}\\ &{+\,\mathbb{E}_{x\sim p(x)}\log p_{D}(y\le K|x)+\mathbb{E}_{x\sim p_{G}}\log p_{D}(y=K+1|x),}\end{array}
$$  

where the first term of Eq. (3) denotes the supervised cross-entropy loss, The last two terms of Eq. (3) are the unsupervised losses from the unlabeled and generated data, respectively.  

GoodBadGAN. GoodBadGAN [153] realizes that the generator and discriminator in [152] may not be optimal simultaneously, i.e., the discriminator achieves good performance in SSL, while the generator may generate visually unrealistic samples. The structure of GoodBadGAN is shown in Fig. 2(5). The method gives theoretical justifications of why using bad samples from the generator can boost the SSL performance. Generally, the generated samples, along with the loss function (Eq. (3)), can force the boundary of the discriminator to lie between the data manifolds of different categories, which improves the generalization of the discriminator. Due to the analysis, GoodBadGAN learns a bad generator by explicitly adding a penalty term $\mathbb{E}_{x\sim p_{G}}\log p(x)\mathbb{I}[p(x)\,>\,\epsilon]$ to generate bad samples, where $\mathbb{I}[\cdot]$ is an indicator function and $\epsilon$ is a threshold, which ensures that only high-density samples are penalized while low-density samples are unaffected. Further, to guarantee the strong true-fake belief in the optimal conditions, a conditional entropy term $\begin{array}{r}{\mathbb{E}_{x\sim p_{x}}\sum_{k=1}^{K}\log p_{D}(k|x)}\end{array}$ is added to  

# the discriminator objective function in Eq. (3)  

Localized GAN. Localized GAN [154] focuses on using local coordinate charts to parameterize local geometry of data transformations across different locations manifold rather than the global one. This work suggests that Localized GAN can help train a locally consistent classifier by exploring the manifold geometry. The architecture of Localized GAN is shown in Fig. 2(6). Like the methods introduced in [152], [153], Localized GAN attempts to solve the $K+1$ classification problem that outputs the probability of $x$ being assigned to a class. For a classifier, $\nabla_{z}\bar{D}(G(x,z))$ depicts the change of the classification decision on the manifold formed by $G(x,z),$ and the evolution of $D(\cdot)$ restricted on $G(x,z)$ can be written as  

$$
|D(G(x,z+\sigma z))-D(G(x,z))|^{2}\approx\|\nabla_{x}^{G}D(x)\|^{2}\sigma z,
$$  

which shows that penalizing $\Vert\nabla_{x}^{G}D(x)\Vert^{2}$ can train a robust classifier with a small perturbation $\sigma z$ on a manifold. This probabilistic classifier can be introduced by adding $\begin{array}{r}{\sum_{k=1}^{K}\stackrel{\widehat{}}{\mathbb{E}}_{x\sim p_{x}}\|\nabla_{x}^{G}\log p(y~=~k|x)\|^{2},}\end{array}$ , where $\nabla_{x}^{G}\log{p(y)}\;=$ $k|x)$ is the gradient of the log-likelihood along with the manifold $G(\bar{x},z)$ .  

CT-GAN. CT-GAN [155] combines consistency training with WGAN [156] applied to semi-supervised classification problems. And the structure of CT-GAN is shown in Fig. 2(7). Following [157], this method also lays the Lipschitz continuity condition over the manifold of the real data to improve the improved training of WGAN. Moreover, CTGAN devises a regularization over a pair of samples drawn near the manifold following the most basic definition of the 1-Lipschitz continuity. In particular, each real instance $x$ is perturbed twice and uses a Lipschitz constant to bound the difference between the discriminator’s responses to the perturbed instances $x^{\prime},x^{\prime\prime}$ . Formally, since the value function of WGAN is  

$$
\operatorname*{min}_{G}\operatorname*{max}_{D}\mathbb{E}_{x\sim p_{x}}D(x)-\mathbb{E}_{z\sim p_{z}}D(G(z)),
$$  

where $D$ is one of the sets of 1-Lipschitz function. The objective function for updating the discriminator include: (a) basic Wasserstein distance in Eq. (5), (b) gradient penalty $G P|_{\hat{x}}$ [157] used in the improved training of WGAN, where $\hat{x}\;=\;\epsilon x\,+\,(1\,-\,\epsilon)G(z).$ , and (c) A consistency regularization $C T|_{x^{\prime},x^{\prime\prime}}$ . For semi-supervised classification, CT-GAN uses the Eq. (3) for training the discriminator instead of the Eq.( 5), and then adds the consistency regularization CT |x′,x′′ .  

BiGAN. Bidirectional Generative Adversarial Networks (BiGANs) [158] is an unsupervised feature learning framework. The architecture of BiGAN is shown in Fig. 2(8). In contrast to the standard GAN framework, BiGAN adds an encoder $E$ to this framework, which maps data $x$ to $z^{\prime}$ , resulting in a data pair $(x,z^{\prime})$ . The data pair $(x,z^{\prime})$ and the data pair generated by generator $G$ constitute two kinds of true and fake data pairs. The BiGAN discriminator $D$ is to distinguish the true and fake data pairs. In this work, the value function for training the discriminator becomes,  

$$
\begin{array}{r l r}&{}&{\underset{G,E}{\operatorname*{min}}\,\underset{D}{\operatorname*{max}}\,V(D,E,G)=\mathbb{E}_{x\sim\mathcal{X}}\underset{\log(1-D_{E}(\cdot\vert c))}{\underbrace{\left[\mathbb{E}_{z\sim p_{E}(\cdot\vert c)}\,\left[\log D\left(x,z\right)\right]\right]}}}\\ &{}&{+\mathbb{E}_{z\sim p(z)}\underset{\log(1-D(G(z),z))}{\underbrace{\left[\mathbb{E}_{x\sim p_{G}(\cdot\vert z)}\,\left[\log\left(1-D\left(x,z\right)\right)\right]\right]}}.}\end{array}
$$  

ALI. Adversarially Learned Inference (ALI) [159] is a GAN-like adversarial framework based on the combination of an inference network and a generative model. This framework consists of three networks, a generator, an inference network and a discriminator. The generative network $G$ is used as a decoder to map latent variables $z$ (with a prior distribution) to data distribution $\boldsymbol{x}^{\prime}~=~G(\boldsymbol{z})$ , which can be formed as joint pairs $(x^{\prime},z)$ . The inference network $E$ attempts to encode training samples $x$ to latent variables $z^{\prime}\ =\ \overline{{E(x)}}$ , and joint pairs $(x,z^{\prime})$ are similarly drawn. The discriminator network $D$ is required to distinguish the joint pairs $(x,z^{\prime})$ from the joint pairs $(x^{\prime},z)$ . As discussed above, the central architecture of ALI is regarded as similar to the BiGAN’s (see Fig. 2(8). In semi-supervised settings, this framework adapts the discriminator network proposed in [152], and shows promising performance on semi-supervised benchmarks on SVHN and CIFAR 10. The objective function can be rewritten as an extended version similar to Eq. (6).  

Augmented BiGAN. Kumar et al. [160] propose an extension of BiGAN called Augmented BiGAN for SSL. This framework has a BiGAN-like architecture that consists of an encoder, a generator and a discriminator. Since trained GANs produce realistic images, the generator can be considered to obtain the tangent spaces of the image manifold. The estimated tangents infer the desirable invariances which can be injected into the discriminator to improve SSL performance. In particular, the Augmented BiGAN uses feature matching loss [152], $\|\mathbb{E}_{x\in X}D(E(x),x)-$ $\mathbb{E}_{z\sim p(z)}D(z,G(z))\|_{2}^{2}$ to optimize the generator network and the encoder network. Moreover, to avoid the issue of classswitching (the class of $G(E(x))$ changed during the decoupled training), a third pair $(E(x),\bar{G}(E(x)))$ loss term $\bar{\mathbb{E}_{x\sim p(x)}[\log(1-\bar{D}(E(x),\bar{G_{x}}(E(x))))]}$ is added to the objective function Eq. (6).  

Triple GAN. Triple GAN [161] is presented to address the issue that the generator and discriminator of GAN have incompatible loss functions, i.e., the generator and the discriminator can not be optimal at the same time [152]. The problem has been mentioned in [153], but the solution is different. As shown in Fig. 2(9), the Triple GAN tackles this problem by playing a three-player game. This threeplayer framework consists of three parts, a generator $G$ using a conditional network to generate the corresponding fake samples for the true labels, a classifier $C$ that generates pseudo labels for given real data, and a discriminator $D$ distinguishing whether a data-label pair is from the reallabel dataset or not. This Triple GAN loss function may be written as  

$$
\begin{array}{r l r}&{}&{\underset{C,G}{\operatorname*{min}}\,\underset{D}{\operatorname*{max}}\,V(C,G,D)=\mathbb{E}_{(x,y)\sim p(x,y)}\left[\log D\left(x,y\right)\right]}\\ &{}&{+\;\alpha\mathbb{E}_{(x,y)\sim p_{c}(x,y)}\left[\log\left(1-D\left(x,y\right)\right)\right]}\\ &{}&{+\left(1-\alpha\right)\mathbb{E}_{(x,y)\sim p_{g}(x,y)}\left[\log\left(1-D\left(G\left(y,z\right),y\right)\right)\right],}\end{array}
$$  

where $D$ obtains label information about unlabeled data from the classifier $C$ and forces the generator $G$ to generate the realistic image-label samples.  

Enhanced TGAN. Based on the architecture of Triple GAN [162], Enhanced TGAN [163] modifies the TripleGAN by re-designing the generator loss function and the classifier network. The generator generates images conditioned on class distribution and is regularized by classwise mean feature matching. The classifier network includes two classifiers that collaboratively learn to provide more categorical information for generator training. Additionally, a semantic matching term is added to enhance the semantics consistency with respect to the generator and the classifier network. The discriminator $D$ learned to distinguish the labeled data pair $(x,y)$ from the synthesized data pair $(G(z),\tilde{y})$ and predicted data pair $(x,\bar{y})$ . The corresponding objective function is similar to Eq. (7), where $(G(z),\tilde{y})$ is sampling from the pre-specified distribution $p_{g},$ and $(x,{\bar{y}})$ denotes the predicted data pair determined by $p_{c}(x)$ .  

MarginGAN. MarginGAN [164] is another extension framework based on Triple GAN [162]. From the perspective of classification margin, this framework works better than Triple GAN when used for semi-supervised classification. The architecture of MarginGAN is presented in Fig. 2(10). MarginGAN includes three components like Triple GAN, a generator $G$ which tries to maximize the margin of generated samples, a classifier $C$ used for decreasing margin of fake images, and a discriminator $D$ trained as usual to distinguish real samples from fake images. This method solves the problem that performance is damaged due to the inaccurate pseudo label in ${\mathrm{SSL}},$ and improves the accuracy rate of SSL.  

Triangle GAN. Triangle Generative Adversarial Network ( $\bigtriangleup$ -GAN) [162] introduces a new architecture to match cross-domain joint distributions. The architecture of the $\triangle$ - GAN is shown in Fig. 2(11). The $\triangle$ -GAN can be considered as an extended version of BiGAN [158] or ALI [159]. This framework is a four-branch model that consists of two generators $E$ and $G_{\star}$ , and two discriminators $D_{1}$ and $D_{2}$ . The two generators can learn two different joint distributions by two-way matching between two different domains. At the same time, the discriminators are used as an implicit ternary function, where $D_{2}$ determines whether the data pair is from $(x,y^{\prime})$ or from $(G(z),y)$ , and $D_{1}$ distinguishes real data pair $(x,y)$ from the fake data pair $(G(z),y)$ .  

Structured GAN. Structured GAN [165] studies the problem of semi-supervised conditional generative modeling based on designated semantics or structures. The architecture of Structured GAN (see Fig. 2(12)) is similar to Triangle GAN [162]. Specifically, Structured GAN assumes that the samples $x$ are generated conditioned on two independent latent variables, i.e., $y$ that encodes the designated semantics and $z$ contains other variation factors. Training Structured GAN involves solving two adversarial games that have their equilibrium concentrating at the true joint data distributions $\bigl\vert p(x,z)$ and $p(x,y)$ . The synthesized data pair $(x^{\prime},y)$ and $(x^{\prime},z)$ are generated by generator $G(y,z)$ , where $(x^{\prime},y)$ mix real sample pair $(x,y)$ together as input for training discriminator $D(x,y)$ and $\left(x^{\prime}z\right)$ blends the $E$ ’s outputs pair $(x,z^{\prime})$ for discriminator $D(x,z)$ .  

R3-CGAN. Liu et al. [166] propose a Classconditional GAN with Random Regional Replacement (R3- regularization) technique, called $\bar{R}^{3}$ -CGAN. Their framework and training strategy relies on Triangle GAN [162]. The R3-CGAN architecture comprises four parts, a generator $G$ to synthesize fake images with specified class labels, a classifier $C$ to generate instance-label pairs of real unlabeled images with pseudo-labels, a discriminator $D_{1}$ to identify real or fake pairs, and another discriminator $D_{2}$ to distinguish two types of fake data. Specifically, CutMix [167], a Random Regional Replacement strategy, is used to construct two types of between-class instances (crosscategory instances and real-fake instances). These instances are used to regularize the classifier $C$ and discriminator $D_{1}$ . Through the minimax game among the four players, the class-specific information is effectively used for the downstream.  

Summary. Comparing with the above discussed SemiGANs methods, we find that the main difference lies in the number and type of the basic modules, such as generator, encoder, discriminator, and classifier. As shown in Fig. 2(1), we find the evolutionary relationship of the Semi-GANs models. Overall, CatGAN [149] and CCGAN [150] extend the basic GAN by including additional information in the model, such as category information and in-painted images. Based on Improved GAN [152], Localized GAN [154] and CT-GAN [155] consider the local information and consistency regularization, respectively. BiGAN [158] and ALI [159] learn an inference model during the training process by adding an Encoder module. In order to solve the problem that the generator and discriminator can not be optimal at the same time, Triple-GAN [161] adds an independent classifier instead of using a discriminator as a classifier.  

# 3.2 Semi-supervised VAE  

Variational AutoEncoders (VAEs) [168], [169] are flexible models which combine deep autoencoders with generative latent-variable models. The generative model captures representations of the distributions rather than the observations of the dataset, and defines the joint distribution in the form of $p(x,z)\,=\,p(z)p(x|z),$ where $p(z)$ is a prior distribution over latent variables $z$ . Since the true posterior $p(z|x)$ is generally intractable, the generative model is trained with the aid of an approximate posterior distribution $q(z|x)$ . The architecture of VAEs is a two-stage network, an encoder to construct a variational approximation $q(z|x)$ to the posterior $p(z|x),$ , and a decoder to parameterize the likelihood $p(x|z)$ . The variational approximation of the posterior maximizes the marginal likelihood, and the evidence lower bound (ELBO) may be written as  

$$
\begin{array}{r l r}&{}&{\log p(x)=\log\mathbb{E}_{q(z|x)}[\frac{p(z)p(x|z)}{q(z|x)}]}\\ &{}&{\geq\mathbb{E}_{q(z|x)}[\log p(z)p(x|z)-\log q(z|x)].}\end{array}
$$  

There are three reasons why latent-variable models can be useful for SSL: (a) It is a natural way to incorporate unlabeled data, (b) The ability to disentangle representations can be easily implemented via the configuration of latent variables, and (c) It also allows us to use variational neural methods. In the following, we review several representative latent variable methods for semi-supervised learning.  

![](images/87392a66d10dafd7e03ed04087a58c5f35a90d81a2860e50df899e5febc6106a.jpg)  
Fig. 3. A glimpse of probabilistic graphical models used for VAE-based deep generative semi-supervised methods. Each method contains two models, the generative model $P$ and the inference model $Q$ . The variational parameters $\theta$ and $\phi$ are learned jointly by the incoming connections (i.e., deep neural networks).  

SSVAEs. SSVAEs denotes the VAE-based generative models with latent encoder representation proposed in [170]. The first one, i.e., the latent-feature discriminative model, referred to M1 [170], can provide more robust latent features with a deep generative model of the data. As shown in Fig. 3(1), $p_{\theta}(x|\bar{z})$ is a non-linear transformation, e.g., a deep neural network. Latent variables $z$ can be selected as a Gaussian distribution or a Bernoulli distribution. An approximate sample of the posterior distribution on the latent variable $q_{\phi}\bar{(}z|x)$ is used as the classifier feature for the class label $y$ . The second one, namely Generative semisupervised model, referred to M2 [170], describes the data generated by a latent class variable $y$ and a continuous latent variable $z,$ is expressed as $p_{\theta}(x|z,y)p(z)p(y)$ (as depicted in Fig. 3(2)). $p(y)$ is the multinomial distribution, where the class labels $y$ are treated as latent variables for unlabeled data. $p_{\theta}(x|z,y)$ is a suitable likelihood function. The inferred posterior distribution $q_{\phi}(z|y,x)$ can predict any missing labels.  

Stacked generative semi-supervised model, called $\mathrm{M}1\mathrm{+}\mathrm{M}2,$ , uses the generative model M1 to learn the new latent representation $z_{1}.$ , and uses the embedding from $z_{1}$ instead of the raw data $x$ to learn a generative semi-supervised model M2. As shown in Fig. 3(3), the whole process can be abstracted as follows:  

$$
p_{\theta}(x,y,z_{1},z_{2})=p(y)p(z_{2})p_{\theta}(z_{1}|y,z_{2})p_{\theta}(x|z_{1}),
$$  

where $p_{\theta}(z_{1}|y,z_{2})$ and $p_{\theta}(x|z_{1})$ are parameterised as deep neural networks. In all the above models, $q_{\phi}(z|x)$ is used to approximate the true posterior distribution $p(z|x).$ , and following the variational principle, the boundary approximation lower bound of the model is derived to ensure that the approximate posterior probability is as close to the true posterior probability as possible.  

ADGM. Auxiliary Deep Generative Models (ADGM) [171] extends SSVAEs [170] with auxiliary variables, as depicted in Fig. 3(4). The auxiliary variables can improve the variational approximation and make the variational distribution more expressive by training deep generative models with multiple stochastic layers.  

Adding the auxiliary variable $a$ leaves the generative model of $x,y$ unchanged while significantly improving the representative power of the posterior approximation. An additional inference network is introduced such that:  

$$
q_{\phi}(a,y,z|x)=q_{\phi}(z|a,y,x)q_{\phi}(y|a,x)q_{\phi}(a|x).
$$  

The framework has the generative model $p$ defined as $p_{\theta}(a)p_{\theta}(y)p_{\theta}(z)p_{\theta}(x|z,y),$ , where $a,y,z$ are the auxiliary variable, class label, and latent features, respectively.  

Learning the posterior distribution is intractable. Thus we define the approximation as $q_{\phi}(a|x)q_{\phi}(z|y,x)$ and a classifier $q_{\phi}(y|a,\bar{x})$ . The auxiliary unit $a$ actually introduces a class-specific latent distribution between $x$ and $y,$ resulting in a more expressive distribution $q_{\phi}(y|a,x)$ . Formally, [171] employs the similar variational lower bound $\begin{array}{r l r}{\mathbb{E}_{q_{\phi}(a,z|x)}[\mathrm{\bar{log}}\,\bar{p}_{\theta}(a,x,y,z)}&{{}-}&{\log q_{\phi}(a,z|x,y)]}\end{array}$ on the marginal likelihood, with $\begin{array}{r l r}{q_{\phi}(a,z|x,y)}&{{}=}&{}\end{array}$ $q_{\phi}(a|x)q_{\phi}(z|y,\bar{x})$ . Similarly, the unlabeled ELBO is $\begin{array}{r l r}{\mathbb{E}_{q_{\phi}(a,y,z|x)}[\log p_{\theta}(a,x,y,z)}&{{}-}&{\log q_{\phi}(a,y,z|x)]}\end{array}$ with $q_{\phi}^{-}(a,y,z|x)=q_{\phi}(z|y,x)q_{\phi}(y|a,x)q_{\phi}(a|x)$ .  

Interestingly, by reversing the direction of the dependence between $x$ and $^{a,}$ a model similar to the stacked version of M1 and M2 is recovered (Fig. 3(3)), with what the authors denote skip connections from the second stochastic layer and the labels to the inputs $x$ . In this case the generative model is affected, and the authors call this the Skip Deep Generative Model (SDGM). This model is able to be trained end to end using stochastic gradient descent (SGD) (according to the [171] the skip connection between $z$ and $x$ is crucial for training to converge). Unsurprisingly, joint training for the model improves significantly upon the performance presented in [170].  

Infinite VAE. Infinite VAE [172] proposes a mixture model for combining variational autoencoders, a nonparametric Bayesian approach. This model can adapt to suit the input data by mixing coefficients by a Dirichlet process.It combines Gibbs sampling and variational inference that enables the model to learn the input’s underlying structures efficiently. Formally, Infinite VAE employs the mixing coefficients to assist SSL by combining the unsupervised generative model and a supervised discriminative model. The infinite mixture generative model as,  

$$
p(c,\pi,x,z)=p(c|\pi)p_{\alpha}(\pi)p_{\theta}(x|c,z)p(z),
$$  

where $c$ denotes the assignment matrix for each instance to a VAE component where the VAE- $^{i}$ can best reconstruct instance $i,\,\pi$ is the mixing coefficient prior for $c,$ drawn from a Dirichlet distribution with parameter $\alpha$ . Each latent variable $z_{i}$ in each VAE is drawn from a Gaussian distribution.  

Disentangled VAE. Disentangled VAE [173] attempts to learn disentangled representations using partially-specified graphical model structures and distinct encoding aspects of the data into separate variables. It explores the graphical model for modeling a general dependency on observed and unobserved latent variables with neural networks, and a stochastic computation graph [174] is used to infer with and train the resultant generative model. For this purpose, importance sampling estimates are used to maximize the lower bound of both the supervised and semi-supervised likelihoods. Formally, this framework considers the conditional probability $q_{y,z|x},$ which has a factorization $q_{\phi}(y,z|x)\;=\;$ $q_{\phi}(y|x,z)q_{\phi}(\bar{z}|\bar{x})$ rather than $q_{\phi}(y,z|x)=q_{\phi}(z|x,y)q_{\phi}(y|x)$ in [170], which means we can no longer compute a simple Monte Carlo estimator by sampling from the unconditional distribution $q_{\phi}(z|x)$ . Thus, the variational lower bound for supervised term expand below,  

$$
\begin{array}{r}{\mathbb{E}_{q_{\phi}(z|x,y)}[\log p_{\theta}(x|y,z)p(y)p(z)-q_{\phi}(y,z|x)].}\end{array}
$$  

SDVAE. Semi-supervised Disentangled VAE (SDVAE) [175] incorporates the label information to the latent representations by encoding the input disentangled representation and non-interpretable representation. The disentangled variable captures categorical information, and the noninterpretable variable consists of other uncertain information from the data. As shown in Fig. 3(5), SDVAE assumes the disentangled variable $v$ and the non-interpretable variable $u$ are independent condition on $x,$ i.e., $q_{\phi}(u,v|x)\;=\;$ $q_{\phi}(u|x)q_{\phi}(v|x)$ . This means that $q_{\phi}(v|x)$ is the encoder for the disentangled representation, and $q_{\phi}(u|x)$ denotes the encoder for non-interpretable representation. Based on those assumptions, the variational lower bound is written as:  

$$
\mathbb{E}_{q(u|x),q(v|x)}[\log p(x|u,v)p(v)p(u)-\log q(u|x)q(v|x)].
$$  

ReVAE. Reparameterized VAE (ReVAE) [176] develops a novel way to encoder supervised information, which can capture label information through auxiliary variables instead of latent variables in the prior work [170]. The graphical model is illustrated in Fig. 3(6). In contrast to SSVAEs, ReVAE captures meaningful representations of data with a principled variational objective. Moreover, ReVAE carefully designed the mappings between auxiliary and latent variables. In this model, a conditional generative model $p_{\psi}(z|y)$ is introduced to address the requirement for inference at test time. Similar to [170] and [171], ReVAE treats $y$ as a known observation when the label is available in the supervised setting, and as an additional variable in the unsupervised case. In particular, the latent space can be partitioned into two disjoint subsets under the assumption that label information captures only specific aspects.  

Summary. As the name indicates, Semi-supervised VAE applies the VAE architecture for handling SSL problems. An advantage of these methods is that meaningful representations of data can be learned by the generative latent-variable models. The basic framework of these Semi-supervised VAE methods is M2 [170]. On the basis of the M2 framework, ADGM [171] and ReVAE [176] consider introducing additional auxiliary variables, although the roles of the auxiliary variables in the two models are different. Infinite VAE [172] is a hybrid of several VAE models to improve the performance of the entire framework. Disentangled VAE [173] and SDVAE [175] solve the semi-supervised VAE problem by different disentangled methods. Under semi-supervised conditions, when a large number of labels are unobserved, the key to this kind of method is how to deal with the latent variables and label information.  

# 4 CONSISTENCY REGULARIZATION  

In this section, we introduce the consistency regularization methods for semi-supervised deep learning. In these methods, a consistency regularization term is applied to the final loss function to specify the prior constraints assumed by researchers. Consistency regularization is based on the manifold assumption or the smoothness assumption, and describes a category of methods that the realistic perturbations of the data points should not change the output of the model [13]. Consequently, consistency regularization can be regarded to find a smooth manifold on which the dataset lies by leveraging the unlabeled data [177].  

The most common structure of consistency regularization SSL methods is the Teacher-Student structure. As a student, the model learns as before, and as a teacher, the model generates targets simultaneously. Since the model itself generates targets, they may be incorrect and then used by themselves as students for learning. In essence, the consistency regularization methods suffer from confirmation bias [68], a risk that can be mitigated by improving the target’s quality. Formally, following [178], we assume that dataset $X$ consists of a labeled subset $X_{l}$ and an unlabeled subset $X_{u}$ . Let $\theta^{\prime}$ denote the weight of the target, and $\theta$ denote the weights of the basic student. The consistency constraint is defined as:  

$$
\mathbb{E}_{x\in X}\mathcal{R}(f(\theta,x),\mathcal{T}_{x}),
$$  

where $f(\theta,x)$ is the prediction from model $f(\theta)$ for input $x$ . $\tau_{x}$ is the consistency target of the teacher. $\mathcal{R}(\cdot,\cdot)$ measures the distance between two vectors and is usually set to Mean Squared Error (MSE) or KL-divergence. Different consistency regularization techniques vary in how they generate the target. There are several ways to boost the target $\tau_{x}$ quality. One strategy is to select the perturbation rather than additive or multiplicative noise carefully. Another technique is to consider the teacher model carefully instead of replicating the student model.  

Ladder Network. Ladder Network [65], [179] is the first successful attempt towards using a Teacher-Student model that is inspired by a deep denoising AutoEncoder. The structure of the Ladder Network is shown in Fig. 4(1). In Encoder, noise $\zeta$ is injected into all hidden layers as the corrupted feedforward path $\begin{array}{r}{x+\zeta\,\rightarrow\,\frac{\mathrm{Encoder}}{f(\cdot)}\,\stackrel{{\,\,\,\,\,\,}}{\rightarrow}\,\tilde{z}_{1}\,\rightarrow\,\tilde{z}_{2}}\end{array}$ and shares the mappings $f(\cdot)$ with the clean encoder feedforward path $\begin{array}{r}{x\,\to\,{\frac{\mathrm{Encoder}}{f(\cdot)}}\,\to\,z_{1}\,\to\,z_{2}\,\to\,y}\end{array}$ . The decoder path $\begin{array}{r}{\tilde{z}_{1}\ \to\ \tilde{z}_{2}\ \to\ \frac{\mathrm{Decoder}}{g(\cdot,\cdot)}\ \to\ \hat{z}_{2}\ \to\ \hat{z}_{1}}\end{array}$ consists of the denoising functions $g(\cdot,\cdot)$ and the unsupervised denoising square error $\mathcal{R}$ on each layer consider as consistency loss between $\hat{z}_{i}$ and $z_{i}$ . Through latent skip connections, the ladder network is differentiated from regular denoising AutoEncoder. This feature allows the higher layer features to focus on more abstract invariant features for the task. Formally, the ladder network unsupervised training loss $\mathcal{L}_{u}$ or the consistency loss is computed as the MSE between the activation of the clean encoder $z_{i}$ and the reconstructed activations $\hat{z}_{i}$ . Generally, $\mathcal{L}_{u}$ is  

$$
\mathbb{E}_{x\in X}\mathcal{R}\left(f\left(\theta,x\right),g\left(f\left(\theta,x+\zeta\right)\right)\right).
$$  

Π Model. Unlike the perturbation used in Ladder Network, Π Model [66] is to create two random augmentations of a sample for both labeled and unlabeled data. Some techniques with non-deterministic behavior, such as randomized data augmentation, dropout, and random maxpooling, make an input sample pass through the network several times, leading to different predictions. The structure of the Π Model is shown in Fig. 4(2). In each epoch of the training process for Π Model, the same unlabeled sample propagates forward twice, while random perturbations are introduced by data augmentations and dropout. The forward propagation of the same sample may result in different predictions, and the Π Model expects the two predictions to be as consistent as possible. Therefore, it provides an unsupervised consistency loss function,  

![](images/468ab1c46299722e782e8d3addd31195f4ffa57a6814a48d95caf29eee50d7c3.jpg)  
Fig. 4. A glimpse of the diverse range of architectures used for consistency regularization semi-supervised methods. In addition to the identifiers in the figure, $\zeta$ denotes the perturbation noise, and ${\mathcal R}$ is the consistency constraint.  

$$
\mathbb{E}_{x\in X}\mathcal{R}(f(\theta,x,\zeta_{1}),f(\theta,x,\zeta_{2})),
$$  

which minimizes the difference between the two predictions.  

Temporal Ensembling. Temporal Ensembling [67] is similar to the $\Pi$ Model, which forms a consensus prediction under different regularization and input augmentation conditions. The structure of Temporal Ensembling is shown in Fig. 4(3). It modifies the Π Model by leveraging the Exponential Moving Average (EMA) of past epochs predictions. In other words, while $\Pi$ Model needs to forward a sample twice in each iteration, Temporal Ensembling reduces this computational overhead by using EMA to accumulate the predictions over epochs as $\tau_{x}$ . Specifically, the ensemble outputs $Z_{i}$ is updated with the network outputs $z_{i}$ after each training epoch, i.e., $Z_{i}\ \gets\ \alpha Z_{i}\,+\,(1-\overset{\cdot}{\alpha})\,z_{i},$ where $\alpha$ is a momentum term. During the training process, the $Z$ can be considered to contain an average ensemble of $f(\cdot)$ outputs due to Dropout and stochastic augmentations. Thus, consistency loss is:  

$$
\mathbb{E}_{x\in X}\mathcal{R}(f(\theta,x,\zeta_{1}),\mathrm{EMA}(f(\theta,x,\zeta_{2}))).
$$  

Mean Teacher. Mean Teacher [68] averages model weights using EMA over training steps and tends to produce a more accurate model instead of directly using output predictions. The structure of Mean Teacher is shown in Fig. 4(4). Mean Teacher consists of two models called Student and Teacher. The student model is a regular model similar to the Π Model, and the teacher model has the same architecture as the student model with exponential moving averaging the student weights. Then Mean Teacher applied a consistency constraint between the two predictions of student and teacher:  

$$
\mathbb{E}_{x\in X}\mathcal{R}(f(\theta,x,\zeta),f(\mathrm{EMA}(\theta),x,\zeta^{\prime})).
$$  

VAT. Virtual Adversarial Training [180] proposes the concept of adversarial attack for consistency regularization. The structure of VAT is shown in Fig. 4(5). This technique aims to generate an adversarial transformation of a sample, which can change the model prediction. Specifically, the adversarial training technique is used to find the optimal adversarial perturbation $\gamma$ of a real input instance $x$ such that $\gamma\le\delta$ . Afterward, the consistency constraint is applied between the model’s output of the original input sample and the perturbed one, i.e.,  

$$
\mathbb{E}_{x\in X}\mathcal{R}(f(\theta,x),g(\theta,x+\gamma^{a d v})),
$$  

where $\gamma^{a d v}=\operatorname{argmax}_{\gamma;\|\gamma\|\leqslant\delta}\mathcal{R}\big(f(\theta,x),g(\theta,x+\gamma)\big)$  

Dual Student. Dual Student [178] extends the Mean Teacher model by replacing the teacher with another student. The structure of Dual Student is shown in Fig. 4(6). The two students start from different initial states and are optimized through individual paths during training. The authors also defined a novel concept, “stable sample”, along with a stabilization constraint to avoid the performance bottleneck produced by a coupled EMA Teacher-Student model. Hence, their weights may not be tightly coupled, and each learns its own knowledge. Formally, Dual Student checks whether $x$ is a stable sample for student $i$ :  

$$
\mathcal{C}_{x}^{i}=\left\{p_{x}^{i}=p_{\bar{x}}^{i}\right\}_{1}\&\left(\left\{\mathcal{M}_{x}^{i}>\xi\right\}_{1}\left\|\left\{\mathcal{M}_{\bar{x}}^{i}>\xi\right\}_{1}\right),
$$  

where $\mathcal{M}_{x}^{i}=\left\|f\left(\boldsymbol{\theta}^{i},\boldsymbol{x}\right)\right\|_{\infty},$ and the stabilization constraint:  

$$
\begin{array}{r}{\mathcal{L}_{s t a}^{i}=\left\{\left\{\varepsilon^{i}>\varepsilon^{j}\right\}_{1}\mathcal{R}\left(f\left(\theta^{i},x\right),f\left(\theta^{j},x\right)\right)\;\;\mathcal{C}^{i}=\mathcal{C}^{j}=1\;.}\\ {\mathcal{C}^{i}\mathcal{R}\left(f\left(\theta^{i},x\right),f\left(\theta^{j},x\right)\right)\;\;\;\;\;\;\;\;\;\;\;\;\;\;\;\mathrm{otherwise}\;\;\;}\end{array}\right.}\end{array}
$$  

SWA. Stochastic Weight Averaging (SWA) [181] improves generalization than conventional training. The aim is to average multiple points along the trajectory of stochastic gradient descent (SGD) with a cyclical learning rate and seek much flatter solutions than SGD. The consistencybased SWA [182] observes that SGD fails to converge on the consistency loss but continues to explore many solutions with high distances apart in predictions on the test data. The structure of SWA is shown in Fig. 4(7). The SWA procedure also approximates the Teacher-Student approach, such as Π Model and Mean Teacher with a single model. The authors propose fast-SWA, which adapts the SWA to increase the distance between the averaged weights by using a longer cyclical learning rate schedule and diversity of the corresponding predictions by averaging multiple network weights within each cycle. Generally, the consistency loss can be rewritten as follows:  

TABLE 3 Summary of Consistency Regularization Methods   


<html><body><table><tr><td>Methods</td><td>Techniques</td><td>Transformations</td><td>Consistency Constraints</td></tr><tr><td>Ladder</td><td>AdditionalGaussianNoise</td><td>input</td><td>Ex∈xR(f(0,α), f(0, + ))</td></tr><tr><td>Network II Model</td><td>in every neural layer DifferentStochasticAugmentations</td><td>input</td><td>Ex∈xR(f(0,,S1), f (0,α,2))</td></tr><tr><td>Temporal</td><td>DifferentStochasticAugmentation</td><td>input,</td><td>Ex∈xR(f(0,,S1),EMA(f (0,,S2)))</td></tr><tr><td>Ensembling</td><td>and EMA the predictions DifferentStochasticAugmentation</td><td>predictions input,</td><td></td></tr><tr><td>Mean Teacher VAT</td><td>and EMA theweights Adversarialperturbation</td><td>weights input</td><td>Ex∈xR(f (0,,S),f (EMA(0) ,, S)) Ex∈xR(f (0,x), f (0,x, adu)</td></tr><tr><td>Dual Student</td><td>Stablesample</td><td>input,</td><td>Ex∈xR(f (STA(0,i),S1),f(STA(θ,j),2))</td></tr><tr><td></td><td>andstabilization constraint</td><td>weights input,</td><td></td></tr><tr><td>SWA</td><td>StochasticWeight Averaging AdversarialperturbationandStochastic</td><td>weights input,</td><td>Ex∈xR(f(0,α),f(SWA(θ),,S))</td></tr><tr><td>VAdD</td><td>Augmentation (dropout mask) AutoAugment/RandAugmentforimage;</td><td>weights</td><td>Ex∈xR (f (0,,e),f (0,, ead))</td></tr><tr><td>UDA WCP</td><td>Back-Translationfortext Additiveperturbationonnetworkweights, DropConnectperturbationfornetwork structure</td><td>input input, networkstructure</td><td>Ex∈xR(f(0,x), f(0,x,S)) Ex∈xR(f (0,x),g(θ +,α))</td></tr></table></body></html>  

$$
\mathbb{E}_{x\in X}\mathcal{R}(f(\theta,x),f(\mathrm{SWA}(\theta),x,\zeta)).
$$  

VAdD. In VAT, the adversarial perturbation is defined as an additive noise unit vector applied to the input or embedding spaces, which has improved the generalization performance of SSL. Similarly, Virtual Adversarial Dropout (VAdD) [183] also employs adversarial training in addition to the Π Model. The structure of VAdD is shown in Fig. 4(8). Following the design of Π Model, the consistency constraint of VAdD is computed from two different dropped networks: one dropped network uses a random dropout mask, and the other applies adversarial training to the optimized dropout network. Formally, $f(\theta,x,\epsilon)$ denotes an output of a neural network with a random dropout mask, and the consistency loss incorporated adversarial dropout is described as:  

$$
\mathbb{E}_{x\in X}\mathcal{R}(f(\theta,x,\epsilon^{s}),f(\theta,x,\epsilon^{a d v})),
$$  

where ϵadv $\begin{array}{r}{\epsilon^{a d v}\,=\,\operatorname*{argmax}_{\epsilon;\|\epsilon^{s}-\epsilon\|_{2}\le\delta H}\mathcal{R}\bigl(f\bigl(\theta,x,\epsilon^{s}\bigr),f\bigl(\theta,x,\epsilon\bigr)\bigr);}\end{array}$ $f(\theta,x,\epsilon^{a d v})$ represents an adversarial target; $\epsilon^{a d v}$ is an adversarial dropout mask; $\epsilon^{s}$ is a sampled random dropout mask instance; $\delta$ is a hyperparameter controlling the intensity of the noise, and $H$ is the dropout layer dimension.  

WCP. A novel regularization mechanism for training deep SSL by minimizing the Worse-case Perturbation (WCP) is presented by Zhang et al. [69]. The structure of WCP is shown in Fig. 4(9). WCP considers two forms of WCP regularizations – additive and DropConnect perturbations, which impose additive perturbation on network weights and make structural changes by dropping the network connections, respectively. Instead of generating an ensemble of randomly corrupted networks, the WCP suggests enhancing the most vulnerable part of a network by making the most resilient weights and connections against the worst-case perturbations. It enforces an additive noise on the model parameters $\zeta,$ along with a constraint on the norm of the noise. In this case, the WCP regularization becomes,  

$$
\mathbb{E}_{x\in X}\mathcal{R}\big(f(\theta,x),g(\theta+\zeta,x)\big).
$$  

The second perturbation is at the network structure level by DropConnect, which drops some network connections. Specifically, for parameters $\theta_{.}$ , the perturbed version is $(1-$ $\alpha)\theta,$ and the $\alpha\,=\,1$ denotes a dropped connection while $\alpha\,=\,0$ indicates an intact one. By applying the consistency constraint, we have  

$$
\mathbb{E}_{x\in X}\mathcal{R}(f(\theta,x),f((1-\alpha)\theta,x)).
$$  

UDA. UDA stands for Unsupervised Data Augmentation [184] for image classification and text classification. The structure of UDA is shown in Fig. 4(10). This method investigates the role of noise injection in consistency training and substitutes simple noise operations with highquality data augmentation methods, such as AutoAugment [185], RandAugment [186] for images, and Back-Translation [187], [188] for text. Following the consistency regularization framework, the UDA [184] extends the advancement in supervised data augmentation to SSL. As discussed above, let $\bar{f}(\theta,x,\zeta)$ be the augmentation transformation from which one can draw an augmented example $(x,\zeta)$ based on an original example $x$ . The consistency loss is:  

$$
\mathbb{E}_{x\in X}{\mathcal{R}}(f(\theta,x),f(\theta,x,\zeta)),
$$  

where $\zeta$ represents the data augmentation operator to create an augmented version of an input $x$ .  

Summary. The core idea of consistency regularization methods is that the output of the model remains unchanged under realistic perturbation. As shown in TABLE 3, Consistency constraints can be considered at three levels: input dataset, neural networks and training process. From the input dataset perspective, perturbations are usually added to the input examples: additive noise, random augmentation, or even adversarial training. We can drop some layers or connections for the networks, as WCP [69]. From the training process, we can use SWA to make the SGD fit the consistency training or EMA parameters of the model for some training epochs as new parameters.  

# 5 GRAPH-BASED METHODS  

Graph-based semi-supervised learning (GSSL) has always been a hot subject for research with a vast number of successful models [189], [190], [191] because of its wide variety of applicability. The basic assumption in GSSL is that a graph can be extracted from the raw dataset where each node represents a training sample, and each edge denotes some similarity measurement of the node pair. In this section, we review graph embedding SSL methods, and the principal goal is to encode the nodes as small-scale vectors representing their role and the structure information of their neighborhood.  

For graph embedding methods, we have the formal definition for the embedding on the node level. Given the graph $\mathcal{G}(\boldsymbol{\upnu},\boldsymbol{\mathcal{E}}).$ , the node that has been embedded is a mapping result of $f_{\mathbf{z}}\;:\;v\;\rightarrow\;\mathbf{z}_{v}\;\in\;\mathbb{R}^{d},\forall v\;\in\;\mathcal{V}$ such that $d\ll|\nu|,$ and the $f_{\mathbf{z}}$ function retains some of the measurement of proximity, defined in the graph $\mathcal{G}$ .  

The unified form of the loss function is shown as Eq. (28) for graph embedding methods.  

$$
\mathcal{L}(f_{\mathbf{z}})=\sum_{(x,y)\in X_{l}}(x,y,f_{\mathbf{z}})+\alpha\sum_{x\in X}\mathcal{R}(x,f_{\mathbf{z}}),
$$  

where $f_{\mathbf{z}}$ is the embedding function.  

Besides, we can divide graph embedding methods into shallow embedding and deep embedding based on the use or not use of deep learning techniques. The encoder’s function, as a simple lookup function based on node ID, is built with shallow embedding methods including DeepWalk [192], LINE [193] and node2vec [194], whereas the deep embedding encoder is far more complicated, and the deep learning frameworks have to make full use of node attributes.  

As deep learning progresses, recent GSSL research has switched from shallow embedding methods to deep embedding methods in which the $f_{\mathbf{z}}$ embedding term in the Eq. (28) is focused on deep learning models. Two classes can be identified among all deep embedding methods: AutoEncoder-based methods and GNN-based methods.  

# 5.1 AutoEncoder-based methods  

AutoEncoder-based approaches also differ as a result of using a unary decoder rather than a pairwise method. More precisely, every node, $i,$ is correlated to a neighborhood vector $\mathbf{s}_{i}\in\mathbb{R}^{|\breve{\nu}|}$ . The $\mathbf{s}_{i}$ vector contains $i$ ’s similarity with all other graph nodes and acts as a high-dimensional vector representation of $i$ in the neighborhood. The aim of the auto-encoding technique is to embed nodes using hidden embedding vectors like $\mathbf{s}_{i}$ in so as to reconstruct the original information from such embeddings (Fig. 5(1)):  

$$
\mathrm{Dec}\left(\mathrm{Enc}\left(\mathbf{s}_{i}\right)\right)=\mathrm{Dec}\left(\mathbf{z}_{i}\right)\approx\mathbf{s}_{i}.
$$  

In other words, the loss for these methods takes the following form:  

$$
\mathcal{L}=\sum_{i\in V}\left\|\mathrm{Dec}\left(\mathbf{z}_{i}\right)-\mathbf{s}_{i}\right\|_{2}^{2}.
$$  

SDNE. Structural deep network embedding (SDNE) is developed by Wang et al. [195] by using deep autoencoders to maintain the first and second-order network proximities. This is managed by optimizing the two proximities simultaneously. The process utilizes highly nonlinear functions to obtain its embedding. This framework consists of two parts: unsupervised and supervised. The first is an autoencoder to identify an embedding for a node to rebuild the neighborhood. The second is based on Laplacian Eigenmaps [196], which imposes a penalty when related vertices are distant from each other.  

DNGR. (DNGR) [197] combines random surfing with autoencoders. The model includes three components: random surfing, positive pointwise mutual information (PPMI) calculation, and stacked denoising autoencoders. The random surfing design is used to create a stochastic matrix equivalent to the similarity measure matrix in HOPE [198] on the input graph. The matrix is transformed into a PPMI matrix and fed into a stacked denoising autoencoder to obtain the embedding. The PPMI matrix input ensures that the autoencoder model captures a higher proximity order. The use of stacked denoising autoencoders also helps make the model robust in the event of noise in the graph, as well as in seizing the internal structure needed for downstream tasks.  

GAE & VGAE. Both MLP-based and RNN-based strategies only consider the contextual information and ignore the feature information of the nodes. To encode both, GAE [199] uses GCN [200]. The encoder is in the form,  

$$
\operatorname{Enc}(A,X)=\operatorname{GraphConv}\left(\sigma(\operatorname{GraphConv}(A,X))\right),
$$  

where $\mathrm{{GraphConv}(\cdot)}$ is a graph convolutional layer defined in [200], $\sigma(\cdot)$ is the activation function and $A\,,X$ is adjacency matrix and attribute matrix respectively. The decoder of GAE is defined as  

$$
\begin{array}{r}{\mathrm{Dec}\left(\mathbf{z}_{u},\mathbf{z}_{v}\right)=\mathbf{z}_{u}^{T}\mathbf{z}_{v}.}\end{array}
$$  

Variational GAE (VGAE) [199] learns about the distribution of the data in which the variation lower bound $\mathcal{L}$ is optimized directly by reconstructing the adjacency matrix.  

$$
{\mathcal{L}}=\mathbb{E}_{q(\mathbf{Z}|X,A)}[\log p(A\mid\mathbf{Z})]-\mathrm{KL}[q(\mathbf{Z}\mid X,A)\|p(\mathbf{Z})],
$$  

where $\mathrm{KL}[q(\cdot)||p(\cdot)]$ is the Kullback-Leibler divergence between $q(\cdot)$ and $p(\cdot)$ . Moreover, we have  

$$
q(\mathbf{Z}\mid X,A)=\prod_{i=1}^{N}\mathcal{N}\left(\mathbf{z}_{i}\mid\mu_{i},\mathrm{diag}\left(\sigma_{i}^{2}\right)\right),
$$  

and  

$$
p(A\mid\mathbf{Z})=\prod_{i=1}^{N}A_{i j}\sigma\left(\mathbf{z}_{i}^{\top}\mathbf{z}_{j}\right)+(1-A_{i j})\left(1-\sigma\left(\mathbf{z}_{i}^{\top}\mathbf{z}_{j}\right)\right).
$$  

![](images/8797cb27370294c94d5c3713c0a6fd1cb74d6b550f4a3e6400c4b032dc958ba1.jpg)  
Fig. 5. A glimpse of the diverse range of architectures used for graph-based semi-supervised methods. Specifically, in figure (3), “PPMI” is short for positive pointwise mutual information. In figure (4), $A$ denotes the adjacency matrix, and in figure (5), pink A represents node A.  

Summary. It should be noted from Eq. (29) that the encoder unit does depend on the specific $\mathbf{s}_{i}$ vector, which gives the crucial information relating to the local community structure of $v_{i}$ . TABLE 4 sums up the main components of these methods, and their architectures are compared as Fig. 5.  

# 5.2 GNN-based methods  

Several updated, deep embedding strategies are designed to resolve major autoencoder-based method disadvantages by building certain specific functions that rely on the local community of the node but not necessarily the whole graph (Fig. 5(5)). The GNN, which is widely used in state-ofthe-art deep embedding approaches, can be regarded as a general guideline for the definition of deep neural networks on graphs.  

Like other deep node-level embedding methods, a classifier is trained to predict class labels for the labeled nodes. Then it can be applied to the unlabeled nodes based on the final, hidden state of the GNN-based model. Since GNN consists of two primary operations: the aggregate operation and the update operation, the basic GNN is provided, and then some popular GNN extensions are reviewed with a view to enhancing each process, respectively.  

Basic GNN. As Gilmer et al. [201] point out, the critical aspect of a basic GNN is that the benefit of neural message passing is to exchange and update messages between each node pair by using neural networks.  

More specifically, a hidden embedding $\mathbf{h}_{u}^{(k)}$ in each neural message passing through the GNN basic iteration is updated according to message or information from the neighborhood within $\mathcal{N}(u)$ according to each node $u$ . This general message can be expressed according to the update rule:  

$$
\begin{array}{r l}&{\mathbf{h}_{u}^{(k+1)}}\\ &{\ =\ \mathop{\mathbf{Update}}^{(k)}\left(\mathbf{h}_{u}^{(k)},\ \mathop{\mathbf{Aggregate}}^{(k)}\left(^{k}\right)\left(\left\{\mathbf{h}_{v}^{(k)},\mathop{\forall v}\in\mathcal{N}(u)\right\}\right)\right)}\\ &{\ =\ \mathop{\mathbf{Update}}^{(k)}\left(\mathbf{h}_{u}^{(k)},\mathbf{m}_{\mathcal{N}(u)}^{(k)}\right),\ \ }\end{array}
$$  

where  

$$
{\bf m}_{\mathcal{N}(u)}^{(k)}=\mathrm{\Aggregate}^{\mathrm{\tiny~(}k)}\left(\left\{{\bf h}_{v}^{(k)},\forall v\in\mathcal{N}(u)\right\}\right).
$$  

It is worth noting that the functions Update and Aggregate must generally be differentiable in Eq. (36). The new state is generated in accordance with Eq. (36) when the neighborhood message is combined with the previous hidden embedding state. After a number of iterations, the last hidden embedding state converges so that each node’s final status is created as the output. Formally, we have, $\mathbf{z}_{u}=\mathbf{h}_{u}^{(K)},\forall u\in\mathcal{V}$ .  

The basic GNN model is introduced before reviewing many other GNN-based methods designed to perform SSL tasks. The basic version of GNN aims to simplify the original GNN model, proposed by Scarselli et al. [202].  

The basic GNN message passing is defined as:  

$$
\mathbf{h}_{u}^{(k)}=\sigma\left(\mathbf{W}_{\mathrm{self}}^{(k)}\mathbf{h}_{u}^{(k-1)}+\mathbf{W}_{\mathrm{neigh}}^{(k)}\sum_{v\in\mathcal{N}(u)}\mathbf{h}_{v}^{(k-1)}+\mathbf{b}^{(k)}\right),
$$  

where Ws(eklf) , $\mathbf{W}_{\mathrm{self}}^{(k)}\,,\mathbf{W}_{\mathrm{neigh}}^{(k)}$ are trainable parameters and $\sigma$ is the activation function. In principle, the messages from the neighbors are summarized first. Then, the neighborhood information and the previously hidden node results are integrated by an essential linear combination. Finally, the joint information uses a nonlinear activation function. It is worth noting that the GNN layer can be easily stacked together following Eq. (38). The last layer’s output in the GNN model is regarded as the final node embedding result to train a classifier for the downstream SSL tasks.  

As previously mentioned, GNN models have all sorts of variants that try to some degree boost their efficiency and robustness. All of them, though, obey the Eq. (36) neural message passing structure, regardless of the GNN version explored previously.  

GCN. As mentioned above, the most simple neighborhood aggregation operation only calculates the sum of the neighborhood encoding states. The critical issue with this approach is that nodes with a large degree appear to derive a better benefit from more neighbors compared to those with a lower number of neighbors.  

One typical and straightforward approach to this problem is to normalize the aggregation process depending on the central node degree. The most popular method is to use the following symmetric normalization Eq. (39) employed by Kipf et al. [200] in the graph convolutional network (GCN) model as Eq. (39).  

$$
\mathbf{m}_{N(u)}=\sum_{v\in\mathcal{N}(u)}\frac{\mathbf{h}_{v}}{\sqrt{|\mathcal{N}(u)|\,|\,\mathcal{N}(v)\,|}}
$$  

GCN fully uses the uniform neighborhood grouping technique. Consequently, the GCN model describes the up  

TABLE 4 Summary of AutoEncoder-based Deep Graph Embedding Methods   


<html><body><table><tr><td>Method</td><td>Encoder</td><td>Decoder</td><td>SimilarityMeasure</td><td>LossFunction</td><td>Time Complexity</td></tr><tr><td>SDNE [195]</td><td>MLP</td><td>MLP</td><td>Su</td><td>∑uev IIDec (Zu)- Sull?</td><td>O(vll)</td></tr><tr><td>DNGR [197]</td><td>MLP</td><td>MLP</td><td>Su</td><td>∑uev IDec(Zu）-Sull</td><td>0 (1V|2)</td></tr><tr><td>GAE[199]</td><td>GCN</td><td>Z u</td><td>Auu</td><td>∑uev !! IIDec(Zu)-AuIl2</td><td>o(vl|)</td></tr><tr><td>VGAE[199]</td><td>GCN</td><td>T Zu Z u</td><td>Auv</td><td>Eq(Z|x,A) [log p(A | Z)] - KL[q(Z | X, A)Ilp(Z)]</td><td>O(vl|l)</td></tr></table></body></html>  

date function as Eq. (40). As it is indirectly specified in the update function, no aggregation operation is defined.  

$$
\mathbf{h}_{u}^{(k)}=\sigma\left(\mathbf{W}^{(k)}\sum_{v\in\mathcal{N}(u)\cup\{u\}}\frac{\mathbf{h}_{v}}{\sqrt{|\mathcal{N}(u)||\mathcal{N}(v)|}}\right)
$$  

A vast range of GCN variants is available to boost SSL performance from various aspects [203], [204]. Li et al. [205] were the first to have a detailed insight into the performance and lack of GCN in SSL tasks. Subsequently, GCN extensions for SSL started to propagate [206] [207] [208] [209] [210].  

GAT. In addition to more general ways of set aggregation, another common approach for improving the aggregation layer of GNNs is to introduce certain attention mechanisms [211]. The basic theory is to give each neighbor a weight or value of significance which is used to weight the influence of this neighbor during the aggregation process. The first GNN to use this focus was Cucurull et al.’s Graph Attention Network (GAT), which uses attention weights to describe a weighted neighboring amount:  

$$
\mathbf{m}_{\mathcal{N}(u)}=\sum_{v\in\mathcal{N}(u)}\alpha_{u,v}\mathbf{h}_{v},
$$  

where $\alpha_{u,v}$ denotes the attention on neighbor $\boldsymbol{v}\,\in\,\mathcal{N}(\boldsymbol{u})$ when we are aggregating information at node $u$ . In the original GAT paper, the attention weights are defined as  

$$
\alpha_{u,v}=\frac{\exp\left(\mathbf{a}^{\top}\left[\mathbf{W}\mathbf{h}_{u}\oplus\mathbf{W}\mathbf{h}_{v}\right]\right)}{\sum_{v^{\prime}\in\mathcal{N}(u)}\exp\left(\mathbf{a}^{\top}\left[\mathbf{W}\mathbf{h}_{u}\oplus\mathbf{W}\mathbf{h}_{v^{\prime}}\right]\right)},
$$  

where a is a trainable attention vector, $\mathbf{W}$ is a trainable matrix, and denotes the concatenation operation.  

GraphSAGE. Over-smoothing is an obvious concern for GNN. Over-smoothing after several message iterations is almost unavoidable as the node-specific information is “washed away.” The use of vector concatenations or skip connections, which both preserve information directly from the previous rounds of the update, is one fair way to lessen this concern. For general purposes, Updatebase denotes a basic update rule.  

One of the simplest updates in GraphSage [212] for skip connection uses a concatenation vector to contain more node-level information during a messages passage process:  

$$
\left(\mathbf{h}_{u},\mathbf{m}_{\mathcal{N}}(u)\right)=\left[\mathrm{Update}_{\mathrm{base}}\left(\mathbf{h}_{u},\mathbf{m}_{\mathcal{N}(u)}\right)\oplus\mathbf{h}_{u}\right],
$$  

where the output from the basic update function is concatenated with the previous layer representation of the node. The critical observation is that this designed model is encouraged to detach information during the message passing operation.  

GGNN. Parallel to the above work, researchers also are motivated by the approaches taken by recurrent neural networks (RNNs) to improve stability. One way to view the GNN message propagation algorithm is to gather an observation from neighbors of the aggregation process and then change each node’s hidden state. In this respect, specific approaches can be used explicitly based on observations to check the hidden states of RNN architectures.  

For example, one of the earliest GNN variants which put this idea into practice is proposed by Li et al. [213], in which the update operation is defined as Eq. (44)  

$$
\mathbf{h}_{u}^{(k)}=\mathrm{GRU}\left(\mathbf{h}_{u}^{(k-1)},\mathbf{m}_{\mathcal{N}(u)}^{(k)}\right),
$$  

where GRU is a gating mechanism function in recurrent neural networks, introduced by Kyunghyun Cho et al. [214]. Another related approach would be similar improvements based on the LSTM architecture [215].  

Summary. The main point of graph-based models for DSSL is to perform label inference on a constructed similarity graph so that the label information can be propagated from the labeled samples to the unlabeled ones by incorporating both the topological and feature knowledge. Moreover, the involvement of deep learning models in GSSL helps generate more discriminative embedding representations that are beneficial for the downstream SSL tasks, thanks to the more complex encoder functions.  

# 6 PSEUDO-LABELING METHODS  

The pseudo-labeling methods differ from the consistency regularization methods in that the consistency regularization methods usually rely on consistency constraint of rich data transformations. In contrast, pseudo-labeling methods rely on the high confidence of pseudo-labels, which can be added to the training data set as labeled data. There are two main patterns, one is to improve the performance of the whole framework based on the disagreement of views or multiple networks, and the other is self-training, in particular, the success of self-supervised learning in unsupervised domain makes some self-training self-supervised methods realized.  

# 6.1 Disagreement-based models  

The idea of disagreement-based SSL is to train multiple learners for the task and exploit the disagreement during the learning process [216]. In such model designs, two or three different networks are trained simultaneously and label unlabeled samples for each other.  

Deep co-training. Co-training [27] framework assumes each data $x$ in the dataset has two different and complementary views, and each view is sufficient for training a good classifier. Because of this assumption, Co-training learns two different classifiers on these two views (see Fig. 6(1)). Then the two classifiers are applied to predict each view’s unlabeled data and label the most confident candidates for the other model. This procedure is iteratively repeated till unlabeled data are exhausted, or some condition is met (such as the maximum number of iterations is reached). Let $v_{1}$ and $v_{2}$ as two different views of data such that $\boldsymbol{x}\,=\,(v_{1},v_{2})$ . Co-training assumes that $\mathcal{C}_{1}$ as the classifier trained on View-1 $v_{1}$ and $\mathcal{C}_{2}$ as the classifier trained on View-2 $v_{2}$ have consistent predictions on $\mathcal{X}$ . In the objective function, the Co-training assumption can be model as:  

![](images/843ed0d18c8c2cc3553b01485d8ab0c1a08546174e6eaaa74df5d380d9a4174f.jpg)  
Fig. 6. A glimpse of the diverse range of architectures used for pseudo-label semi-supervised methods. The same color and structure have the same meaning as shown in Figure 4. $M_{s}$ denotes shared module, $M_{1}$ , $M_{2}$ and $M_{3}$ are three different modules in Tri-Net. “Rotation ” and “Exemplar” represent $S^{4}\bar{L}$ -Rotation and ${\bar{S}}^{4}L$ -Exemplar, respectively.  

$$
\mathcal{L}_{c t}=H(\frac{1}{2}(\mathcal{C}_{1}(v_{1})+\mathcal{C}_{2}(v_{2})))-\frac{1}{2}(H(\mathcal{C}_{1}(v_{1}))+H(\mathcal{C}_{2}(v_{2}))),
$$  

where $H(\cdot)$ denotes the entropy, the Co-training assumption is formulated as $\mathcal{C}(x)\,=\,\mathcal{C}_{1}\(\dot{v_{1}})\,=\,\mathcal{C}_{2}(v_{2}),\forall x\,=\,(v_{1},\dot{v_{2}})\,\sim$ $\mathcal{X}$ . On the labeled dataset $X_{L},$ the supervised loss function can be the standard cross-entropy loss  

$$
{\mathcal{L}}_{s}=H(y,{\mathcal{C}}_{1}(v_{1}))+H(y,{\mathcal{C}}_{2}(v_{2})),
$$  

where $H(p,q)$ is the cross-entropy between distribution $p$ and $q$ .  

The key to the success of Co-training is that the two views are different and complementary. However, the loss function $\mathcal{L}_{c t}$ and $\mathcal{L}_{s}$ only ensure the model tends to be consistent for the predictions on the dataset. To address this problem, [217] forces to add the View Difference Constraint to the previous Co-training model, and formulated as:  

$$
\exists{\mathcal{X}}^{\prime}:{\mathcal{C}}_{1}(v_{1})\neq{\mathcal{C}}_{2}(v_{2}),\forall x=(v_{1},v_{2})\sim{\mathcal{X}}^{\prime},
$$  

where $\mathcal{X^{\prime}}$ denotes the adversarial examples of $\chi$ , thus $\mathcal{X}^{\prime}\cap\mathcal{X}\ =\ \emptyset$ . In the loss function, the View Difference Constraint can be model by minimizing the cross-entropy between $\mathcal{C}_{2}(x)$ and $\mathcal{C}_{1}(g_{2}(x))$ , where $g(\cdot)$ denotes the adversarial examples generated by the generative model. Then, this part loss function is:  

$$
\mathcal{L}_{d i f}(x)=H(\mathcal{C}_{1}(x),\mathcal{C}_{2}(g_{1}(x)))\!+\!H(\mathcal{C}_{2}(x),p_{1}(g_{2}(x))).
$$  

Some other research works also explore to apply cotraining into neural network model training. For example, [218] treats the RGB and depth of an image as two independent views for object recognition. Then, co-training is performed to train two networks on the two views. Next, a fusion layer is added to combine the two-stream networks for recognition, and the overall model is jointly trained. Besides, in sentiment classification, [219] considers the original review and the automatically constructed anonymous review as two opposite sides of one review and then apply the co-training algorithm. One crucial property of [219] is that two views are opposing and therefore associated with opposite class labels.  

Tri-Net. Tri-net [220], a deep learning-based method inspired by the tri-training [221]. The tri-training learns three classifiers from three different training sets, which are obtained by utilizing bootstrap sampling. The framework (as shown in Fig. 6(2)) of tri-net can be intuitively described as follows. Output smearing [222] is used to add random noise to the labeled sample to generate different training sets and help learn three initial modules. The three models then predict the pseudo-label for unlabeled data. With the predictions of two modules for unlabeled instances consistent, the pseudo-label is considered to be confident and stable. The labeled sample is added to the training set of the third module, and then the third module is fine-tuned on the augmented training set. During the augmentation process, the three modules become more and more similar, so the three modules are fine-tuned on the training sets respectively to ensure diversity. Formally, the output smearing is used to construct three different training sets $\{\mathcal{L}_{o s}^{j}=\stackrel{\smile}{(x_{i},\hat{y}_{i}^{j})},j=1,2,3\}$ from the initial labeled set $X_{L}$ . Then tri-net can be initialized by minimizing the sum of standard softmax cross-entropy loss function from the three training sets,  

$$
\begin{array}{c}{\displaystyle{\mathcal{L}=\frac{1}{L}\sum_{i=1}^{L}\left\{\mathcal{L}_{y}(M_{1}(M_{S}(x_{i})),\hat{y}_{i}^{1})+\mathcal{L}_{y}(M_{2}(M_{S}(x_{i})),\hat{y}_{i}^{2})\right.}}\\ {\displaystyle{\left.+\mathcal{L}_{y}(M_{3}(M_{S}(x_{i})),\hat{y}_{i}^{3})\right\},}\end{array}
$$  

where $\mathcal{L}_{y}$ is the standard softmax cross-entropy loss function; $M_{S}$ denote a shared module, and $M_{1},M_{2},M_{3}$ is the three different modules; $M_{j}(M_{S}(x_{i})),j\ =\ 1,2,3$ denotes the outputs of the shared features generated by $M_{S}$ . In the whole procedure, the unlabeled sample can be pseudolabeled by the maximum posterior probability,  

$$
\begin{array}{l}{{y=\underset{k\in\{1,2,\dots,K\}}{\operatorname{argmax}}\;\left\{p(M_{1}(M_{S}(x))=k|x)+\right.}}\\ {{\left.p(M_{2}(M_{S}(x))=k|x)+p(M_{3}(M_{S}(x))=k|x)\right\}.}}\end{array}
$$  

Summary. The disagreement-based SSL methods exploit the unlabeled data by training multiple learners, and the “disagreement” among these learners is crucial. When the data has two sufficient redundancy and conditional independence views, Deep Co-training [217] improves the disagreement by designing a View Difference Constraint. Tri-Net [220] obtains three labeled datasets by bootstrap sampling and trains three different learners. These methods in this category are less affected by model assumptions, non-convexity of the loss function and the scalability of the learning algorithms.  

# 6.2 Self-training models  

Self-training algorithm leverages the model’s own confident predictions to produce the pseudo labels for unlabeled data. In other words, it can add more training data by using existing labeled data to predict the labels of unlabeled data.  

EntMin. Entropy Minimization (EntMin) [223] is a method of entropy regularization, which can be used to realize SSL by encouraging the model to make low-entropy predictions for unlabeled data and then using the unlabeled data in a standard supervised learning setting. In theory, entropy minimization can prevent the decision boundary from passing through a high-density data points region, otherwise it would be forced to produce low-confidence predictions for unlabeled data.  

Pseudo-label. Pseudo-label [224] proposes a simple and efficient formulation of training neural networks in a semisupervised fashion, in which the network is trained in a supervised way with labeled and unlabeled data simultaneously. As illustrated in Fig. 6(3), the model is trained on labeled data in a usual supervised manner with a crossentropy loss. For unlabeled data, the same model is used to get predictions for a batch of unlabeled samples. The maximum confidence prediction is called a pseudo-label, which has the maximum predicted probability.  

That is, the pseudo-label model trains a neural network with the loss function ${\mathcal{L}},$ where:  

$$
\mathcal{L}=\frac{1}{n}\sum_{m=1}^{n}\sum_{i=1}^{K}\mathcal{R}(y_{i}^{m},f_{i}^{m})+\alpha(t)\frac{1}{n^{\prime}}\sum_{m=1}^{n^{\prime}}\sum_{i=1}^{K}\mathcal{R}(y_{i}^{'m},f_{i}^{'m}),
$$  

where $n$ is the number of mini-batch in labeled data for SGD, $n^{\prime}$ for unlabeled data, $f_{i}^{m}$ is the output units of $m$ ’s sample in labeled data, $y_{i}^{m}$ is the label of that, $y_{i}^{'m}$ for unlabeled data, $y_{i}^{'m}$ is the pseudo-label of that for unlabeled data, $\alpha(t)$ is a coefficient balancing the supervised and unsupervised loss terms.  

Noisy Student. Noisy Student [225] proposes a semisupervised method inspired by knowledge distillation [226] with equal-or-larger student models. The framework is shown in Fig. 6(4). The teacher EfficientNet [227] model is first trained on labeled images to generate pseudo labels for unlabeled examples. Then a larger EfficientNet model as a student is trained on the combination of labeled and pseudo-labeled examples. These combined instances are augmented using data augmentation techniques such as RandAugment [228], and model noise such as Dropout and stochastic depth are also incorporated in the student model during training. After a few iterations of this algorithm, the student model becomes the new teacher to relabel the unlabeled data and this process is repeated.  

$S^{4}L$ . Self-supervised Semi-supervised Learning $(S^{4}L)$ [229] tackles the problem of SSL by employing selfsupervised learning [230] techniques to learn useful representations from the image databases. The architecture of $S^{4}L$ is shown in Fig. 6(5). The conspicuous self-supervised techniques are predicting image rotation [231] and exemplar [232], [233]. Predicting image rotation is a pretext task that anticipates an angle of the rotation transformation applied to an input example. In $S^{4}L,$ there are four rotation degrees $\{0^{\circ},90^{\bar{\circ}},180^{\circ},270^{\circ}\}$ to rotate input images. The $S^{4}{\bar{L}}$ -Rotation loss is the cross-entropy loss on outputs predicted by those rotated images. $S^{4}\bar{L}$ -Exemplar introduces an exemplar loss which encourages the model to learn a representation that is invariant to heavy image augmentations. Specifically, eight different instances of each image are produced by inception cropping [234], random horizontal mirroring, and HSV-space color randomization as in [232]. Following [230], the loss term on unsupervised images uses the batch hard triplet loss [235] with a soft margin.  

MPL. In the SSL, the target distributions are often generated on unlabeled data by a shaped teacher model trained on labeled data. The constructions for target distributions are heuristics that are designed prior to training, and cannot adapt to the learning state of the network training. Meta Pseudo Labels (MPL) [236] designs a teacher model that assigns distributions to input examples to train the student model. Throughout the course of the student’s training, the teacher observes the student’s performance on a heldout validation set, and learns to generate target distributions so that if the student learns from such distributions, the student will achieve good validation performance. The training procedure of MPL involves two alternating processes. As shown in Fig. 6(6), the teacher $g_{\phi}(\cdot)$ produces the conditional class distribution $g_{\phi}(x)$ to train the student. The pair $(x,g_{\phi}(x))$ is then fed into the student network $f_{\theta}(\cdot)$ to update its parameters $\theta$ from the cross-entropy loss. After the student network updates its parameters, the model evaluates the new parameters $\theta^{\prime}$ based on the samples from the held-out validation dataset. Since the new parameters of the student depend on the teacher, the dependency allows us to compute the gradient of the loss to update the teacher’s parameters.  

EnAET. Different from the previous semi-supervised methods and $S^{4}L$ [229], EnAET [237] trains an Ensemble of Auto-Encoding Transformations to enhance the learning ability of the model. The core part of this framework is that EnAET integrates an ensemble of spatial and nonspatial transformations to self-train a good feature representation [238]. EnAET incorporates four spatial transformations and a combined non-spatial transformation. The spatial transformations are Projective transformation, Affine transformation, Similarity transformation and Euclidean transformation. The non-spatial transformation is composed of different colors, contrast, brightness and sharpness with four strength parameters. As shown in Fig. 6(7), EnAET learns an encoder $E\ :\ x\ \rightarrow\ E(x),t(x)\ \rightarrow\ E(t(x))$ on an original instance and its transformations. Meanwhile, a decoder $D\,:\,[E(x),E(t(x))]\,\to\,{\hat{t}}$ is learned to estimate $\hat{t}$ of input transformation. Then, we can get an AutoEncoding  

$$
\mathcal{L}_{A E T}=\mathbb{E}_{x,t(x)}\|D[E(x),E(t(x))]-t(x)\|^{2},
$$  

and EnAET adds the AET loss to the SSL loss as a regularization term. Apart from the AET loss, EnAET explore a pseudo-labeling consistency by minimizing the $\mathrm{KL}$ divergence between $P(\boldsymbol{y}|\boldsymbol{x})$ on an original sample $x$ and $P(\bar{y}|t(x))$ on a transformation $t(x)$ .  

SimCLRv2. SimCLRv2 [239] modifies SimCLR [240] for SSL problems. Following the paradigm of supervised finetuning after unsupervised pretraining, SimCLRv2 uses unlabeled samples in a task-agnostic way, and shows that a big (deep and wide) model can surperisingly effective for semisupervised learning. As shown in Fig. 6(8), the SimCLRv2 can be summarized in three steps: unsupervised or selfsupervised pre-training, supervised fine-tuning on $1\%$ or $10\%$ labeled samples, and self-training with task-specific unlabeled examples. In the pre-training step, SimCLRv2 learns representations by maximizing the contrastive learning loss function in latent space, and the loss function is constructed based on the consistency of different augmented views of the same example. The contrastive loss is  

$$
\ell_{i,j}=-\log\frac{\exp(s i m(z_{i},z_{j})/\tau)}{\sum_{k=1}^{2N}\mathbb{I}_{[k\neq i]}\exp(s i m(z_{i},z_{k})/\tau)},
$$  

where $(i,j)$ is a pair of positive example augmented from the same sample. $s i m(\cdot,\cdot)$ is cosine similarity, and $\tau$ is a temperature parameter. In the self-training step, SimCLRv2 uses task-specific unlabeled samples, and the fine-tuning network acts as a teacher model to minimize the following distillation loss,  

$$
\mathcal{L}^{\mathrm{distil}}=-\sum_{x_{i}\in X}\big[\sum_{y}P^{T}(y|x_{i};\tau)\log P^{S}(y|x_{i};\tau)\big],
$$  

where $P^{T}(y|x_{i};\tau)$ and $P^{S}(y|x_{i};\tau)$ are produced by teacher network and student network, respectively.  

Summary. In general, self-training is a way to get more training data by a series of operations to get pseudo-labels of unlabeled data. Both EntMin [223] and Pseudo-label [224] use entropy minimization to get the pseudo-label with the highest confidence as the ground truth for unlabeled data. Noisy Student [225] utilizes a variety of techniques when training the student network, such as data augmentation, dropout and stochastic depth. $S^{4}L$ [229] not only uses data augmentation techniques, but also adds another 4-category task to improve model performance. MPL [236] modifies Pseudo-label [224] by deriving the teacher network’s update rule from the feedback of the student network. Emerging techniques (e.g., rich data augmentation strategies, metalearning, self-supervised learning ) and network architectures (e.g., EfficientNet [227], SimCLR [240]) provide powerful support for the development of self-training methods.  

# 7 HYBRID METHODS  

Hybrid methods combine ideas from the above-mentioned methods such as pseudo-label, consistency regularization and entropy minimization for performance improvement. Moreover, a learning principle, namely Mixup [241], is introduced in those hybrid methods. It can be considered as a simple, data-agnostic data augmentation approach, a convex combination of paired samples and their respective labels. Formally, Mixup constructs virtual training examples,  

$$
\tilde{x}=\lambda x_{i}+(1-\lambda)x_{j},\quad\tilde{y}=\lambda y_{i}+(1-\lambda)y_{j},
$$  

where $\left({x_{i},y_{i}}\right)$ and $(x_{j},y_{j})$ are two instances from the training data, and $\lambda\in[0,1]$ . Therefore, Mixup extends the training data set by a hard constraint that linear interpolations of samples should lead to the linear interpolations of the corresponding labels.  

ICT. Interpolation Consistency Training (ICT) [70] regularizes SSL by encouraging the prediction at an interpolation of two unlabeled examples to be consistent with the interpolation of the predictions at those points. The architecture is shown in Fig.7(1). The low-density separation assumption inspires this method, and Mixup can achieve broad margin decision boundaries. It is done by training the model $\overline{{f(\theta)}}$ to predict $\operatorname{Mix}_{\lambda}(\hat{y}_{j},\hat{y}_{k})$ at location ${\mathrm{Mix}}_{\lambda}(x_{j},x_{k})$ with the Mixup operation: $\mathrm{Mix}_{\lambda}(a,b)=\lambda a+$ $(1-\lambda)b$ . In semi-supervised settings, ICT extends Mixup by training the model $f(\theta,x)$ to predict the “fake label” ${\mathrm{Mix}}_{\lambda}{\big(}f(\theta,{\stackrel{.}{x}}_{j}),f(\theta,x_{k}){\big)}$ at location ${\mathrm{Mix}}_{\lambda}(x_{j},x_{k})$ . Moreover, the model $f_{\theta}$ predict the fake label $\mathrm{Mix}_{\lambda}\big(f_{\theta^{\prime}}(x_{i}),f_{\theta^{\prime}}(x_{j})\big)$ at location ${\mathrm{Mix}}_{\lambda}(x_{i},x_{j}).$ , where $\theta^{\prime}$ is a moving average of $\theta,$ like [68], for a more conservation consistent regularization. Thus, the ICT term is  

# $\mathbb{E}_{x\in X}\mathcal{R}\big(f(\theta,\mathbf{M}\mathbf{i}\mathbf{x}_{\lambda}(x_{i},x_{j})\big),\mathbf{M}\mathbf{i}\mathbf{x}_{\lambda}(f(\theta^{\prime},x_{i}),f(\theta^{\prime},x_{j})\big).$ (55)  

MixMatch. MixMatch [71] combines consistency regularization and entropy minimization in a unified loss function. This model operates by producing pseudo-labels for each unlabeled instance and then training the original labeled data with the pseudo-labels for the unlabeled data using fully-supervised techniques. The main aim of this algorithm is to create the collections $X_{L}^{\prime}$ and $X_{U}^{\prime},$ which are made up of augmented labeled and unlabeled samples that were generated using Mixup. Formally, MixMatch produces an augmentation of each labeled instance $\left({x_{i},y_{i}}\right)$ and $K$ weakly augmented version of each unlabeled instance $\left(x_{j}\right)$ with $k~\in~\{1,\ldots,K\}$ . Then, it generates a pseudolabel ${\bar{y}}_{j}$ for each $x_{j}$ by computing the average prediction across the $K$ augmentations. The pseudo-label distribution is then sharpened by adjusting temperature scaling to get the final pseudo-label $\Tilde{y}_{j}$ . After the data augmentation, the batches of augmented labeled examples and unlabeled with pseudo-label examples are combined, then the whole group is shuffled. This group is divided into two parts: the first $L$ samples were taken as $\mathcal{W}_{L},$ and the remaining taken as $\mathcal{W}_{U}$ . The group $\mathcal{W}_{L}$ and the augmented labeled batch $\tilde{X}_{L}$ are fed into the Mixup algorithm to compute examples $(x^{\prime},y^{\prime})$ where $x^{\prime}\,=\,\lambda x_{1}\,+\,(1\,-\,\lambda)x_{2}$ for $\bar{\lambda^{\mathrm{~\sim~}}}\mathtt{B e t a}(\bar{\alpha_{,}}\alpha)$ . Similarly, Mixup is applied between the remaining $\mathcal{W}_{U}$ and the augmented unlabeled group $\tilde{X}_{U}$ . MixMatch conducts traditional fully-supervised training with a standard crossentropy loss for a supervised dataset and a mean square error for unlabeled data given these mixed-up samples.  

ReMixMatch. ReMixMatch [72] extends MixMatch [71] by introducing distribution alignment and augmentation anchoring. Distribution alignment encourages the marginal distribution of aggregated class predictions on unlabeled data close to the marginal distribution of ground-truth labels. Augmentation anchoring replaces the consistency regularization component of MixMatch. This technique generates multiple strongly augmented versions of input and encourages each output to be close to predicting a weaklyaugmented variant of the same input. A variant of AutoAugment [185] dubbed “CTAugment” is also proposed to produce strong augmentations, which learns the augmentation policy alongside the model training. As the procedure of ReMixmatch presented in Fig. 7(3), an “anchor” is generated by applying weak augmentation to a given unlabeled example and then $K$ strongly-augmented versions of the same unlabeled example using CTAugment.  

![](images/f8cd4b3f7e4e0299793ed32f16c48c7b53ff6ccd387326ff6731c2901791a4a9.jpg)  
Fig. 7. A glimpse of the diverse range of architectures used for hybrid semi-supervised methods. “Mixup” is Mixup operator [241]. “MixMatch” is MixMatch [71] in figure (2). “GMM” is short for Gaussian Mixture Model. “SAug” and “WAug” represent Strong Augmentation and Weak Augmentation, respectively.  

DivideMix. DivideMix [73] presents a new SSL framework to handle the problem of learning with noisy labels. As shown in Fig. 7(4), DivideMix proposes co-divide, a process that trains two networks simultaneously. For each network, a dynamic Gauss Mixed Model (GMM) is fitted on the loss distribution of each sample to divide the training set into labeled data and unlabeled data. The separated data sets are then used to train the next epoch’s networks. In the followup SSL process, co-refinement and co-guessing are used to improve MixMatch [71] and solve the problem of learning with noisy labels.  

FixMatch. FixMatch [242] combines consistency regularization and pseudo-labeling while vastly simplifying the overall method. The key innovation comes from the combination of these two ingredients, and the use of a separate weak and strong augmentation in the consistency regularization approach. Given an instance, only when the model predicts a high-confidence label can the predicted pseudo-label be identified as ground-truth. As shown in Fig.7(5), given an instance $x_{j},$ FixMatch firstly generates pseudo-label ${\hat{y}}_{j}$ for weakly-augmented unlabeled instances $\hat{x}_{j}$ . Then, the model trained on the weakly-augmented samples is used to predict pseudo-label in the stronglyaugmented version of $x_{j}$ . In FixMatch, weak augmentation is a standard flip-and-shift augmentation strategy, randomly flipping images horizontally with a probability. For strong augmentation, there are two approaches which are based on [185], i.e., RandAugment [228] and CTAugment [72]. Moreover, Cutout [243] is followed by either of these strategies.  

Summary. As discussed above, the hybrid methods unit the most successful approaches in ${\mathrm{SSL}},$ such as pseudolabeling, entropy minimization and consistency regularization, and adapt them to achieve state-of-the-art performance. In TABLE 5, we summarize some techniques that can be used in consistency training to improve model performance.  

TABLE 5 Summary of Input Augmentations and Neural Network Transformations   


<html><body><table><tr><td colspan="2">Techniques</td><td colspan="2">Methods</td></tr><tr><td rowspan="5">Input augmentations</td><td>Additional Noise</td><td>Ladder Network [65], WCP [69] II Model [66], Temporal</td></tr><tr><td>Stochastic Augmenta- tion</td><td>Ensembling [67], Mean Teacher [68], Dual Student [178], MixMatch[71], ReMixMatch [72], FixMatch [242]</td></tr><tr><td>Adversarial perturbation</td><td>VAT [180], VAdD [183]</td></tr><tr><td>AutoAugment</td><td>UDA[184],NoisyStudent[225]</td></tr><tr><td>RandAugment</td><td>UDA [184], FixMatch [242]</td></tr><tr><td>CTAugment</td><td>ReMixMatch [72],FixMatch [242]</td></tr><tr><td rowspan="5">Neural network</td><td>Mixup</td><td>ICT [70], MixMatch [71], ReMixMatch [72], DivideMix [73] II Model [66], Temporal</td></tr><tr><td>Dropout</td><td>Ensembling [67], Mean Teacher [68], Dual Student [178], VAdD [183],Noisy Student [225]</td></tr><tr><td>EMA</td><td>Mean Teacher [68], ICT [70]</td></tr><tr><td>transformations SWA Stochastic</td><td>SWA [182]</td></tr><tr><td>depth</td><td>Noisy Student [225]</td></tr><tr><td></td><td>DropConnect</td><td>WCP [69]</td></tr></table></body></html>  

# 8 CHALLENGES AND FUTURE DIRECTIONS  

Although exceptional performance and achieved promising DSSL progress, there are still several open research questions for future work. We outline some of these issues and future directions below.  

Theoretical analysis. Existing semi-supervised approaches predominantly use unlabeled samples to generate constraints and then update the model with labeled data and these constraints. However, the internal mechanism of DSSL and the role of various techniques, such as data augmentations, training methods and loss functions,etc., are not clear. Generally, there is a single weight to balance the supervised and unsupervised loss, which means that all unlabeled instances are equally weighted. However, not all unlabeled data is equally appropriate for the model in practice. To counter this issue, [244] considers how to use a different weight for every unlabeled example. For consistency regularization SSL, [182] investigates how loss geometry interacts with training process. [245] experimentally explores the effects of data augmentation and labeled dataset size on pre-training and self-training, as well as the limitations and interactions of pre-training and self-training. [246] analyzes the property of the consistency regularization methods when data instances lie in the neighborhood of low-dimensional manifolds, especially in the case of efficient data augmentations or perturbations schemes.  

Incorporation of domain knowledge. Most of the SSL approaches listed above can obtain satisfactory results only in ideal situations in which the training dataset meets the designed assumptions and contains sufficient information to learn an insightful learning system. However, in practice, the distribution of the dataset is unknown and does not necessarily meet these ideal conditions. When the distributions of labeled and unlabeled data do not belong to the same one or the model assumptions are incorrect, the more unlabeled data is utilized, the worse the performance will be. Therefore, we can attempt to incorporate richer and more reliable domain knowledge into the model to mitigate the degradation performance. Recent works focusing on this direction have proposed [247], [248], [249], [250], [251] for DSSL.  

Learning with noisy labels. In this survey, models discussed typically consider the labeled data is generally accurate to learn a standard cross-entropy loss function. An interesting consideration is to explore how SSL can be performed for cases where corresponding labeled instances with noisy initial labels. For example, the labeling of samples may be contributed by the community, so we can only obtain noisy labels for the training dataset. One solution to this problem is [252], which augments the prediction objective with consistency where the same prediction is made given similar percepts. Based on graph SSL, [253] introduces a new $L_{1}$ -norm formulation of Laplacian regularization inspired by sparse coding. [254] deals with this problem from the perspective of memorization effects, which proposed a learning paradigm combining co-training and mean teacher.  

Imbalanced semi-supervised learning. The problem of class imbalance is naturally widespread in real-world applications. When the training data is highly imbalanced, most learning frameworks will show bias towards the majority class, and in some extreme cases, may completely ignore the minority class [255], as a result, the efficiency of predictive models will be significantly affected. Nevertheless, to handle the semi-supervised problem, it is commonly assumed that training dataset is uniformly distributed over all class labels. Recently, more and more works have focused on this problem. [256] aligns pseudo-labels with the desirable class distribution in the unlabeled data for SSL with imbalanced labeled data. Based on graph-based semi-supervised methods, [257] copes with various degrees of class imbalance in a given dataset.  

Robust semi-supervised learning. The common of the latest state-of-the-art approaches is the application of consistency training on augmented unlabeled data without changing the model predictions. One attempt is made by VAT [180] and VAdD [183]. Both of them employ adversarial training to find the optimal adversarial example. Another promising approach is data augmentation (adding noise or random perturbations, CutOut [243], RandomErasing [258], HideAndSeek [259] and GridMask [260]), especially advanced data augmentation, such as AutoAugment [185], RandAugment [228], CTAugment [72], and Mixup [241] which also can be considered as a form of regularization.  

Safe semi-supervised learning. In ${\mathrm{SSL}},$ it is generally accepted that unlabeled data can help improve learning performance, especially when labeled data is scarce. Although it is remarkable that unlabeled data can improve learning performance under appropriate assumptions or conditions, some empirical studies [261], [262], [263] have shown that the use of unlabeled data may lead to performance degeneration, making the generalization performance even worse than a model learned only with labeled data in real-world applications. Thus, safe semi-supervised learning approaches are desired, which never significantly degrades learning performance when unlabeled data is used.  

# 9 CONCLUSION  

Deep semi-supervised learning is a promising research field with important real-world applications. The success of deep learning approaches has led to the rapid growth of DSSL techniques. This survey provides a taxonomy of existing DSSL methods, and groups DSSL methods into five categories: Generative models, Consistency Regularization models, Graph-based models, Pseudo-labeling models, and Hybrid models. We provide illustrative figures to compare the differences between the approaches within the same category. Finally, we discuss the challenges of DSSL and some future research directions that are worth further studies.  

# ACKNOWLEDGMENT  

This paper was partially supported by the National Key Research and Development Program of China (No. 2018AAA0100204), and a key program of fundamental research from Shenzhen Science and Technology Innovation Commission (No. JCYJ20200109113403826).  

# REFERENCES  

[1] J. Padmanabhan and J. M. J. Premkumar, “Advanced deep neural networks for pattern recognition: An experimental study,” in SoCPaR, ser. Advances in Intelligent Systems and Computing, vol. 614. Springer, 2016, pp. 166–175.   
[2] K. Yun, A. Huyen, and T. Lu, “Deep neural networks for pattern recognition,” CoRR, vol. abs/1809.09645, 2018.   
[3] Q. Zhang, L. T. Yang, Z. Chen, and P. Li, “A survey on deep learning for big data,” Inf. Fusion, vol. 42, pp. 146–157, 2018.   
[4] T. Tran, T. Pham, G. Carneiro, L. J. Palmer, and I. D. Reid, “A bayesian data augmentation approach for learning deep models,” in NIPS, 2017, pp. 2797–2806.   
[5] A. Krizhevsky, I. Sutskever, and G. E. Hinton, “Imagenet classification with deep convolutional neural networks,” Commun. ACM, vol. 60, no. 6, pp. 84–90, 2017.   
[6] K. He, X. Zhang, S. Ren, and J. Sun, “Deep residual learning for image recognition,” in CVPR. IEEE Computer Society, 2016, pp. 770–778.   
[7] J. Devlin, M. Chang, K. Lee, and K. Toutanova, “BERT: pretraining of deep bidirectional transformers for language understanding,” in NAACL-HLT. Association for Computational Linguistics, 2019, pp. 4171–4186.   
[8] A. Torfi, R. A. Shirvani, Y. Keneshloo, N. Tavvaf, and E. A. Fox, “Natural language processing advancements by deep learning: A survey,” CoRR, vol. abs/2003.01200, 2020.   
[9] I. J. Goodfellow, Y. Bengio, and A. C. Courville, Deep Learning, ser. Adaptive computation and machine learning. MIT Press, 2016.   
[10] Y. LeCun, Y. Bengio, and G. E. Hinton, “Deep learning,” Nat., vol. 521, no. 7553, pp. 436–444, 2015.   
[11] O. Chapelle, B. Scho¨lkopf, and A. Zien, “Introduction to semisupervised learning,” in Semi-Supervised Learning. The MIT Press, 2006, pp. 1–12.   
[12] X. Zhu and A. B. Goldberg, Introduction to Semi-Supervised Learning, ser. Synthesis Lectures on Artificial Intelligence and Machine Learning. Morgan & Claypool Publishers, 2009.   
[13] A. Oliver, A. Odena, C. Raffel, E. D. Cubuk, and I. J. Goodfellow, “Realistic evaluation of deep semi-supervised learning algorithms,” in NeurIPS, 2018, pp. 3239–3250.   
[14] A. K. Agrawala, “Learning with a probabilistic teacher,” IEEE Trans. Inf. Theory, vol. 16, no. 4, pp. 373–379, 1970.   
[15] S. C. Fralick, “Learning to recognize patterns without a teacher,” IEEE Trans. Inf. Theory, vol. 13, no. 1, pp. 57–64, 1967.   
[16] H. J. S. III, “Probability of error of some adaptive patternrecognition machines,” IEEE Trans. Inf. Theory, vol. 11, no. 3, pp. 363–371, 1965.   
[17] D. J. Miller and H. S. Uyar, $^{\prime}\mathrm{A}$ mixture of experts classifier with learning based on both labelled and unlabelled data,” in NIPS. MIT Press, 1996, pp. 571–577.   
[18] K. Nigam, A. McCallum, S. Thrun, and T. M. Mitchell, “Text classification from labeled and unlabeled documents using EM,” Mach. Learn., vol. 39, no. 2/3, pp. 103–134, 2000.   
[19] T. Joachims, “Transductive inference for text classification using support vector machines,” in ICML. Morgan Kaufmann, 1999, pp. 200–209.   
[20] K. P. Bennett and A. Demiriz, “Semi-supervised support vector machines,” in NIPS. The MIT Press, 1998, pp. 368–374.   
[21] Z. Xu, R. Jin, J. Zhu, I. King, and M. R. Lyu, “Efficient convex relaxation for transductive support vector machine,” in Advances in Neural Information Processing Systems 20, J. C. Platt, D. Koller, Y. Singer, and S. T. Roweis, Eds. Curran Associates, Inc., 2007, pp. 1641–1648.   
[22] Z. Xu, R. Jin, J. Zhu, I. King, M. R. Lyu, and Z. Yang, “Adaptive regularization for transductive support vector machine,” in Advances in Neural Information Processing Systems 22, Y. Bengio, D. Schuurmans, J. D. Lafferty, C. K. I. Williams, and A. Culotta, Eds. Curran Associates, Inc., 2009, pp. 2125–2133.   
[23] X. Zhu, Z. Ghahramani, and J. D. Lafferty, “Semi-supervised learning using gaussian fields and harmonic functions,” in ICML. AAAI Press, 2003, pp. 912–919.   
[24] M. Belkin, P. Niyogi, and V. Sindhwani, “Manifold regularization: A geometric framework for learning from labeled and unlabeled examples,” J. Mach. Learn. Res., vol. 7, pp. 2399–2434, 2006.   
[25] A. Blum and S. Chawla, “Learning from labeled and unlabeled data using graph mincuts,” in ICML. Morgan Kaufmann, 2001, pp. 19–26.   
[26] D. Zhou, O. Bousquet, T. N. Lal, J. Weston, and B. Sch¨olkopf, “Learning with local and global consistency,” in NIPS. MIT Press, 2003, pp. 321–328.   
[27] A. Blum and T. M. Mitchell, “Combining labeled and unlabeled data with co-training,” in COLT. ACM, 1998, pp. 92–100.   
[28] O. Chapelle, B. Scho¨lkopf, and A. Zien, Eds., Semi-Supervised Learning. The MIT Press, 2006.   
[29] G. Qi and J. Luo, “Small data challenges in big data era: A survey of recent progress on unsupervised and semi-supervised methods,” CoRR, vol. abs/1903.11260, 2019.   
[30] J. E. van Engelen and H. H. Hoos, “A survey on semi-supervised learning,” Mach. Learn., vol. 109, no. 2, pp. 373–440, 2020.   
[31] Y. Ouali, C. Hudelot, and M. Tami, “An overview of deep semisupervised learning,” CoRR, vol. abs/2006.05278, 2020.   
[32] H. Cevikalp, B. Benligiray, ¨O. N. Gerek, and H. Saribas, “Semisupervised robust deep neural networks for multi-label classification,” in CVPR Workshops. Computer Vision Foundation / IEEE, 2019, pp. 9–17.   
[33] L. Wang, Y. Liu, C. Qin, G. Sun, and Y. Fu, “Dual relation semisupervised multi-label learning,” in AAAI. AAAI Press, 2020, pp. 6227–6234.   
[34] H. Cevikalp, B. Benligiray, and ¨O. N. Gerek, “Semi-supervised robust deep neural networks for multi-label image classification,” Pattern Recognit., vol. 100, p. 107164, 2020.   
[35] O. Chapelle and A. Zien, “Semi-supervised classification by low density separation,” in AISTATS. Society for Artificial Intelligence and Statistics, 2005.   
[36] D. Yarowsky, “Unsupervised word sense disambiguation rivaling supervised methods,” in ACL. Morgan Kaufmann Publishers / ACL, 1995, pp. 189–196.   
[37] V. R. de Sa, “Learning classification with unlabeled data,” in NIPS. Morgan Kaufmann, 1993, pp. 112–119.   
[38] J. Vittaut, M. Amini, and P. Gallinari, “Learning classification with both labeled and unlabeled data,” in $E C M{\bar{L}},$ ser. Lecture Notes in Computer Science, vol. 2430. Springer, 2002, pp. 468– 479.   
[39] O. Chapelle, M. Chi, and A. Zien, “A continuation method for semi-supervised svms,” in ICML, ser. ACM International Conference Proceeding Series, vol. 148. ACM, 2006, pp. 185–192.   
[40] Z. Xu, R. Jin, J. Zhu, I. King, and M. R. Lyu, “Efficient convex relaxation for transductive support vector machine,” in NIPS. Curran Associates, Inc., 2007, pp. 1641–1648.   
[41] X. Zhu, “Learning from labeled and unlabeled data with label propagation,” Tech Report, 2002.   
[42] Y. Bengio, O. Delalleau, and N. L. Roux, “Label propagation and quadratic criterion,” in Semi-Supervised Learning. The MIT Press, 2006, pp. 192–216.   
[43] J. Weston, F. Ratle, H. Mobahi, and R. Collobert, “Deep learning via semi-supervised embedding,” in Neural Networks: Tricks of the Trade (2nd ed.), ser. Lecture Notes in Computer Science. Springer, 2012, vol. 7700, pp. 639–655.   
[44] S. J. Pan and Q. Yang, “A survey on transfer learning,” IEEE Trans. Knowl. Data Eng., vol. 22, no. 10, pp. 1345–1359, 2010.   
[45] C. Tan, F. Sun, T. Kong, W. Zhang, C. Yang, and C. Liu, “A survey on deep transfer learning,” in ICANN, ser. Lecture Notes in Computer Science, vol. 11141. Springer, 2018, pp. 270–279.   
[46] F. Zhuang, Z. Qi, K. Duan, D. Xi, Y. Zhu, H. Zhu, H. Xiong, and Q. He, “A comprehensive survey on transfer learning,” Proc. IEEE, vol. 109, no. 1, pp. 43–76, 2021.   
[47] Y. Li, L. Guo, and Z. Zhou, “Towards safe weakly supervised learning,” IEEE Trans. Pattern Anal. Mach. Intell., vol. 43, no. 1, pp. 334–346, 2021.   
[48] K. Jaskie and A. Spanias, “Positive and unlabeled learning algorithms and applications: A survey,” in IISA. IEEE, 2019, pp. 1–8.   
[49] J. Bekker and J. Davis, “Learning from positive and unlabeled data: a survey,” Mach. Learn., vol. 109, no. 4, pp. 719–760, 2020.   
[50] T. M. Hospedales, A. Antoniou, P. Micaelli, and A. J. Storkey, “Meta-learning in neural networks: A survey,” CoRR, vol. abs/2004.05439, 2020.   
[51] H. Peng, “A comprehensive overview and survey of recent advances in meta-learning,” CoRR, vol. abs/2004.11149, 2020.   
[52] J. Vanschoren, “Meta-learning: A survey,” CoRR, vol. abs/1810.03548, 2018.   
[53] W. Yin, “Meta-learning for few-shot natural language processing: A survey,” CoRR, vol. abs/2007.09604, 2020.   
[54] M. Huisman, J. N. van Rijn, and A. Plaat, “A survey of deep meta-learning,” CoRR, vol. abs/2010.03522, 2020.   
[55] L. Jing and Y. Tian, “Self-supervised visual feature learning with deep neural networks: A survey,” CoRR, vol. abs/1902.06162, 2019.   
[56] X. Liu, F. Zhang, Z. Hou, Z. Wang, L. Mian, J. Zhang, and J. Tang, “Self-supervised learning: Generative or contrastive,” CoRR, vol. abs/2006.08218, 2020.   
[57] A. Jaiswal, A. R. Babu, M. Z. Zadeh, D. Banerjee, and F. Makedon, “A survey on contrastive self-supervised learning,” CoRR, vol. abs/2011.00362, 2020.   
[58] J. Jeong, S. Lee, J. Kim, and N. Kwak, “Consistency-based semisupervised learning for object detection,” in NeurIPS, 2019, pp. 10 758–10 767.   
[59] N. Souly, C. Spampinato, and M. Shah, “Semi supervised semantic segmentation using generative adversarial network,” in ICCV. IEEE Computer Society, 2017, pp. 5689–5697.   
[60] Y. LeCun, “The mnist database of handwritten digits,” http://yann. lecun. com/exdb/mnist/, 1998.   
[61] Y. Netzer, T. Wang, A. Coates, A. Bissacco, B. Wu, and A. Y. Ng, “Reading digits in natural images with unsupervised feature learning,” in NIPS Workshop on Deep Learning and Unsupervised Feature Learning 2011, 2011.   
[62] A. Coates, A. Y. $\mathrm{Ng},$ and H. Lee, “An analysis of single-layer networks in unsupervised feature learning,” in AISTATS, ser. JMLR Proceedings, vol. 15. JMLR.org, 2011, pp. 215–223.   
[63] A. Krizhevsky, “Learning multiple layers of features from tiny images,” in https://www.cs.toronto.edu/ kriz/cifar.html/, 2009.   
[64] A. Krizhevsky, I. Sutskever, and G. E. Hinton, “Imagenet classification with deep convolutional neural networks,” in NIPS, 2012, pp. 1106–1114.   
[65] A. Rasmus, M. Berglund, M. Honkala, H. Valpola, and T. Raiko, “Semi-supervised learning with ladder networks,” in NIPS, 2015, pp. 3546–3554.   
[66] M. Sajjadi, M. Javanmardi, and T. Tasdizen, “Regularization with stochastic transformations and perturbations for deep semisupervised learning,” in NIPS, 2016, pp. 1163–1171.   
[67] S. Laine and T. Aila, “Temporal ensembling for semi-supervised learning,” in ICLR. OpenReview.net, 2017.   
[68] A. Tarvainen and H. Valpola, “Mean teachers are better role models: Weight-averaged consistency targets improve semisupervised deep learning results,” in NIPS, 2017, pp. 1195–1204.   
[69] L. Zhang and G. Qi, “WCP: worst-case perturbations for semisupervised deep learning,” in CVPR. IEEE, 2020, pp. 3911–3920.   
[70] V. Verma, A. Lamb, J. Kannala, Y. Bengio, and D. Lopez-Paz, “Interpolation consistency training for semi-supervised learning,” in IJCAI. ijcai.org, 2019, pp. 3635–3641.   
[71] D. Berthelot, N. Carlini, I. J. Goodfellow, N. Papernot, A. Oliver, and C. Raffel, “Mixmatch: A holistic approach to semi-supervised learning,” in NeurIPS, 2019, pp. 5050–5060.   
[72] D. Berthelot, N. Carlini, E. D. Cubuk, A. Kurakin, K. Sohn, H. Zhang, and C. Raffel, “Remixmatch: Semi-supervised learning with distribution matching and augmentation anchoring,” in ICLR. OpenReview.net, 2020.   
[73] J. Li, R. Socher, and S. C. H. Hoi, “Dividemix: Learning with noisy labels as semi-supervised learning,” in ICLR. OpenReview.net, 2020.   
[74] M. Everingham, L. V. Gool, C. K. I. Williams, J. M. Winn, and A. Zisserman, “The pascal visual object classes (VOC) challenge,” Int. J. Comput. Vis., vol. 88, no. 2, pp. 303–338, 2010.   
[75] T. Lin, M. Maire, S. J. Belongie, J. Hays, P. Perona, D. Ramanan, P. Doll´ar, and C. L. Zitnick, “Microsoft COCO: common objects in context,” in ECCV, ser. Lecture Notes in Computer Science, vol. 8693. Springer, 2014, pp. 740–755.   
[76] O. Russakovsky, J. Deng, H. Su, J. Krause, S. Satheesh, S. Ma, Z. Huang, A. Karpathy, A. Khosla, M. S. Bernstein, A. C. Berg, and F. Li, “Imagenet large scale visual recognition challenge,” Int. J. Comput. Vis., vol. 115, no. 3, pp. 211–252, 2015.   
[77] Y. Tang, J. Wang, B. Gao, E. Dellandr´ea, R. J. Gaizauskas, and L. Chen, “Large scale semi-supervised object detection using visual and semantic knowledge transfer,” in CVPR. IEEE Computer Society, 2016, pp. 2119–2128.   
[78] J. Gao, J. Wang, S. Dai, L. Li, and R. Nevatia, “NOTE-RCNN: noise tolerant ensemble RCNN for semi-supervised object detection,” in ICCV. IEEE, 2019, pp. 9507–9516.   
[79] K. Sohn, Z. Zhang, C. Li, H. Zhang, C. Lee, and T. Pfister, “A simple semi-supervised learning framework for object detection,” CoRR, vol. abs/2005.04757, 2020.   
[80] S. Song, S. P. Lichtenberg, and J. Xiao, “SUN RGB-D: A RGBD scene understanding benchmark suite,” in CVPR. IEEE Computer Society, 2015, pp. 567–576.   
[81] A. Dai, A. X. Chang, M. Savva, M. Halber, T. A. Funkhouser, and M. Nießner, “Scannet: Richly-annotated 3d reconstructions of indoor scenes,” in CVPR. IEEE Computer Society, 2017, pp. 2432–2443.   
[82] A. Geiger, P. Lenz, and R. Urtasun, “Are we ready for autonomous driving? the KITTI vision benchmark suite,” in CVPR. IEEE Computer Society, 2012, pp. 3354–3361.   
[83] N. Zhao, T. Chua, and G. H. Lee, “SESS: self-ensembling semisupervised 3d object detection,” in CVPR. IEEE, 2020, pp. 11 076–11 084.   
[84] Y. S. Tang and G. H. Lee, “Transferable semi-supervised 3d object detection from RGB-D data,” in ICCV. IEEE, 2019, pp. 1931– 1940.   
[85] J. Li, C. Xia, and X. Chen, “A benchmark dataset and saliencyguided stacked autoencoders for video-based salient object detection,” IEEE Trans. Image Process., vol. 27, no. 1, pp. 349–364, 2018.   
[86] F. Perazzi, J. Pont-Tuset, B. McWilliams, L. V. Gool, M. H. Gross, and A. Sorkine-Hornung, “A benchmark dataset and evaluation methodology for video object segmentation,” in CVPR. IEEE Computer Society, 2016, pp. 724–732.   
[87] T. Brox and J. Malik, “Object segmentation by long term analysis of point trajectories,” in ECCV, ser. Lecture Notes in Computer Science, vol. 6315. Springer, 2010, pp. 282–295.   
[88] P. Yan, G. Li, Y. Xie, Z. Li, C. Wang, T. Chen, and L. Lin, “Semisupervised video salient object detection using pseudo-labels,” in ICCV. IEEE, 2019, pp. 7283–7292.   
[89] R. Mottaghi, X. Chen, X. Liu, N. Cho, S. Lee, S. Fidler, R. Urtasun, and A. L. Yuille, “The role of context for object detection and semantic segmentation in the wild,” in CVPR. IEEE Computer Society, 2014, pp. 891–898.   
[90] M. Cordts, M. Omran, S. Ramos, T. Rehfeld, M. Enzweiler, R. Benenson, U. Franke, S. Roth, and B. Schiele, “The cityscapes dataset for semantic urban scene understanding,” in CVPR. IEEE Computer Society, 2016, pp. 3213–3223.   
[91] G. J. Brostow, J. Shotton, J. Fauqueur, and R. Cipolla, “Segmentation and recognition using structure from motion point clouds,” in ECCV, ser. Lecture Notes in Computer Science, vol. 5302. Springer, 2008, pp. 44–57.   
[92] C. Liu, J. Yuen, and A. Torralba, “SIFT flow: Dense correspondence across scenes and its applications,” IEEE Trans. Pattern Anal. Mach. Intell., vol. 33, no. 5, pp. 978–994, 2011.   
[93] J. Xiao, J. Hays, K. A. Ehinger, A. Oliva, and A. Torralba, “SUN database: Large-scale scene recognition from abbey to zoo,” in CVPR. IEEE Computer Society, 2010, pp. 3485–3492.   
[94] S. Gould, R. Fulton, and D. Koller, “Decomposing a scene into geometric and semantically consistent regions,” in ICCV. IEEE Computer Society, 2009, pp. 1–8.   
[95] J. Dai, K. He, and J. Sun, “Boxsup: Exploiting bounding boxes to supervise convolutional networks for semantic segmentation,” in ICCV. IEEE Computer Society, 2015, pp. 1635–1643.   
[96] S. Hong, H. Noh, and B. Han, “Decoupled deep neural network for semi-supervised semantic segmentation,” in NIPS, 2015, pp. 1495–1503.   
[97] G. Papandreou, L. Chen, K. P. Murphy, and A. L. Yuille, “Weaklyand semi-supervised learning of a deep convolutional network for semantic image segmentation,” in ICCV. IEEE Computer Society, 2015, pp. 1742–1750.   
[98] Y. Wei, H. Xiao, H. Shi, Z. Jie, J. Feng, and T. S. Huang, “Revisiting dilated convolution: A simple approach for weakly- and semisupervised semantic segmentation,” in CVPR. IEEE Computer Society, 2018, pp. 7268–7277.   
[99] J. Lee, E. Kim, S. Lee, J. Lee, and S. Yoon, “Ficklenet: Weakly and semi-supervised semantic image segmentation using stochastic inference,” in CVPR. Computer Vision Foundation / IEEE, 2019, pp. 5267–5276.   
[100] S. Mittal, M. Tatarchenko, and T. Brox, “Semi-supervised semantic segmentation with high- and low-level consistency,” CoRR, vol. abs/1908.05724, 2019.   
[101] T. Kalluri, G. Varma, M. Chandraker, and C. V. Jawahar, “Universal semi-supervised semantic segmentation,” in ICCV. IEEE, 2019, pp. 5258–5269.   
[102] M. S. Ibrahim, A. Vahdat, M. Ranjbar, and W. G. Macready, “Semisupervised semantic image segmentation with self-correcting networks,” in CVPR. IEEE, 2020, pp. 12 712–12 722.   
[103] Y. Ouali, C. Hudelot, and M. Tami, “Semi-supervised semantic segmentation with cross-consistency training,” in CVPR. IEEE, 2020, pp. 12 671–12 681.   
[104] X. Zhang, J. J. Zhao, and Y. LeCun, “Character-level convolutional networks for text classification,” in NIPS, 2015, pp. 649– 657.   
[105] P. N. Mendes, M. Jakob, and C. Bizer, “Dbpedia for nlp: A multilingual cross-domain knowledge base,” in Proceedings of the Eight International Conference on Language Resources and Evaluation (LREC’12), Istanbul, Turkey, May 2012.   
[106] M. Chang, L. Ratinov, D. Roth, and V. Srikumar, “Importance of semantic representation: Dataless classification,” in AAAI. AAAI Press, 2008, pp. 830–835.   
[107] A. L. Maas, R. E. Daly, P. T. Pham, D. Huang, A. Y. Ng, and C. Potts, “Learning word vectors for sentiment analysis,” in ACL. The Association for Computer Linguistics, 2011, pp. 142–150.   
[108] X. H. Phan, M. L. Nguyen, and S. Horiguchi, “Learning to classify short and sparse text & web with hidden topics from large-scale data collections,” in WWW. ACM, 2008, pp. 91–100.   
[109] L. Yao, C. Mao, and Y. Luo, “Graph convolutional networks for text classification,” in AAAI. AAAI Press, 2019, pp. 7370–7377.   
[110] D. Vitale, P. Ferragina, and U. Scaiella, “Classification of short texts by deploying topical annotations,” in ser. Lecture Notes in Computer Science, vol. 7224. Springer, 2012, pp. 376– 387.   
[111] B. Pang and L. Lee, “Seeing stars: Exploiting class relationships for sentiment categorization with respect to rating scales,” in ACL. The Association for Computer Linguistics, 2005, pp. 115– 124.   
[112] R. Johnson and T. Zhang, “Semi-supervised convolutional neural networks for text categorization via region embedding,” in NIPS, 2015, pp. 919–927.   
[113] D. D. Lewis, Y. Yang, T. G. Rose, and F. Li, “RCV1: A new benchmark collection for text categorization research,” J. Mach. Learn. Res., vol. 5, pp. 361–397, 2004.   
[114] W. Xu, H. Sun, C. Deng, and Y. Tan, “Variational autoencoder for semi-supervised text classification,” in AAAI. AAAI Press, 2017, pp. 3358–3364.   
[115] T. Miyato, A. M. Dai, and I. J. Goodfellow, “Adversarial training methods for semi-supervised text classification,” in ICLR. OpenReview.net, 2017.   
[116] D. S. Sachan, M. Zaheer, and R. Salakhutdinov, “Revisiting LSTM networks for semi-supervised text classification via mixed objective function,” in AAAI. AAAI Press, 2019, pp. 6940–6948.   
[117] L. Hu, T. Yang, C. Shi, H. Ji, and X. Li, “Heterogeneous graph attention networks for semi-supervised short text classification,” in EMNLP/IJCNLP. Association for Computational Linguistics, 2019, pp. 4820–4829.   
[118] H. Jo and C. Cinarel, “Delta-training: Simple semi-supervised text classification using pretrained word embeddings,” in EMNLP/IJCNLP. Association for Computational Linguistics, 2019, pp. 3456–3461.   
[119] J. Chen, Z. Yang, and D. Yang, “Mixtext: Linguistically-informed interpolation of hidden space for semi-supervised text classification,” in ACL. Association for Computational Linguistics, 2020, pp. 2147–2157.   
[120] P. Budzianowski, T. Wen, B. Tseng, I. Casanueva, S. Ultes, O. Ramadan, and M. Gasic, “Multiwoz - A large-scale multi-domain wizard-of-oz dataset for task-oriented dialogue modelling,” in EMNLP. Association for Computational Linguistics, 2018, pp. 5016–5026.   
[121] X. Huang, J. Qi, Y. Sun, and R. Zhang, “Semi-supervised dialogue policy learning via stochastic reward estimation,” in ACL. Association for Computational Linguistics, 2020, pp. 660–670.   
[122] C. Danescu-Niculescu-Mizil and L. Lee, “Chameleons in imagined conversations: A new approach to understanding coordination of linguistic style in dialogs,” in CMCL@ACL. Association for Computational Linguistics, 2011, pp. 76–87.   
[123] R. Lowe, N. Pow, I. Serban, and J. Pineau, “The ubuntu dialogue corpus: A large dataset for research in unstructured multi-turn dialogue systems,” in SIGDIAL Conference. The Association for Computer Linguistics, 2015, pp. 285–294.   
[124] J. Chang, R. He, L. Wang, X. Zhao, T. Yang, and R. Wang, “A semi-supervised stable variational network for promoting replier-consistency in dialogue generation,” in EMNLP/IJCNLP. Association for Computational Linguistics, 2019, pp. 1920–1930.   
[125] K. Lang, “Newsweeder: Learning to filter netnews,” in ICML. Morgan Kaufmann, 1995, pp. 331–339.   
[126] E. F. T. K. Sang and F. D. Meulder, “Introduction to the conll-2003 shared task: Language-independent named entity recognition,” in CoNLL. ACL, 2003, pp. 142–147.   
[127] E. F. T. K. Sang and S. Buchholz, “Introduction to the conll-2000 shared task chunking,” in CoNLL/LLL. ACL, 2000, pp. 127–132.   
[128] K. Gimpel, N. Schneider, B. O’Connor, D. Das, D. Mills, J. Eisenstein, M. Heilman, D. Yogatama, J. Flanigan, and N. A. Smith, “Part-of-speech tagging for twitter: Annotation, features, and experiments,” in ACL. The Association for Computer Linguistics, 2011, pp. 42–47.   
[129] O. Owoputi, B. O’Connor, C. Dyer, K. Gimpel, N. Schneider, and N. A. Smith, “Improved part-of-speech tagging for online conversational text with word clusters,” in HLT-NAACL. The Association for Computational Linguistics, 2013, pp. 380–390.   
[130] R. T. McDonald, J. Nivre, Y. Quirmbach-Brundage, Y. Goldberg, D. Das, K. Ganchev, K. B. Hall, S. Petrov, H. Zhang, O. T¨ackstr¨om, C. Bedini, N. B. Castello´, and J. Lee, “Universal dependency annotation for multilingual parsing,” in ACL. The Association for Computer Linguistics, 2013, pp. 92–97.   
[131] J. Hockenmaier and M. Steedman, “Ccgbank: A corpus of CCG derivations and dependency structures extracted from the penn treebank,” Comput. Linguistics, vol. 33, no. 3, pp. 355–396, 2007.   
[132] A. M. Dai and Q. V. Le, “Semi-supervised sequence learning,” in NIPS, 2015, pp. 3079–3087.   
[133] M. E. Peters, W. Ammar, C. Bhagavatula, and R. Power, “Semisupervised sequence tagging with bidirectional language models,” in ACL. Association for Computational Linguistics, 2017, pp. 1756–1765.   
[134] M. Rei, “Semi-supervised multitask learning for sequence labeling,” in ACL. Association for Computational Linguistics, 2017, pp. 2121–2130.   
[135] K. Clark, M. Luong, C. D. Manning, and Q. V. Le, “Semisupervised sequence modeling with cross-view training,” in EMNLP. Association for Computational Linguistics, 2018, pp. 1914–1925.   
[136] J. Hajic, M. Ciaramita, R. Johansson, D. Kawahara, M. A. Mart´ı, L. M\`arquez, A. Meyers, J. Nivre, S. Pad´o, J. Step´anek, P. Strana´k, M. Surdeanu, N. Xue, and Y. Zhang, “The conll-2009 shared task: Syntactic and semantic dependencies in multiple languages,” in CoNLL Shared Task. ACL, 2009, pp. 1–18.   
[137] S. Pradhan, A. Moschitti, N. Xue, H. T. Ng, A. Bj¨orkelund, O. Uryupina, Y. Zhang, and Z. Zhong, “Towards robust linguistic analysis using ontonotes,” in CoNLL. ACL, 2013, pp. 143–152.   
[138] M. G. Carneiro, T. H. Cupertino, L. Zhao, and J. L. G. Rosa, “Semisupervised semantic role labeling for brazilian portuguese,” J. Inf. Data Manag., vol. 8, no. 2, pp. 117–130, 2017.   
[139] S. V. Mehta, J. Y. Lee, and J. G. Carbonell, “Towards semisupervised learning for deep semantic role labeling,” in EMNLP. Association for Computational Linguistics, 2018, pp. 4958–4963.   
[140] R. Cai and M. Lapata, “Semi-supervised semantic role labeling with cross-view training,” in EMNLP/IJCNLP. Association for Computational Linguistics, 2019, pp. 1018–1027.   
[141] P. Rajpurkar, J. Zhang, K. Lopyrev, and P. Liang, “Squad: 100, questions for machine comprehension of text,” in EMNLP. The Association for Computational Linguistics, 2016, pp. 2383– 2392.   
[142] M. Joshi, E. Choi, D. S. Weld, and L. Zettlemoyer, “Triviaqa: A large scale distantly supervised challenge dataset for reading comprehension,” in ACL. Association for Computational Linguistics, 2017, pp. 1601–1611.   
[143] J. Oh, K. Torisawa, C. Hashimoto, R. Iida, M. Tanaka, and J. Kloetzer, “A semi-supervised learning approach to why-question answering,” in AAAI. AAAI Press, 2016, pp. 3022–3029.   
[144] B. Dhingra, D. Pruthi, and D. Rajagopal, “Simple and effective semi-supervised question answering,” in NAACL-HLT. Association for Computational Linguistics, 2018, pp. 582–587.   
[145] S. Zhang and M. Bansal, “Addressing semantic drift in question generation for semi-supervised question answering,” in EMNLP/IJCNLP. Association for Computational Linguistics, 2019, pp. 2495–2509.   
[146] I. J. Goodfellow, J. Pouget-Abadie, M. Mirza, B. Xu, D. WardeFarley, S. Ozair, A. C. Courville, and Y. Bengio, “Generative adversarial nets,” in NIPS, 2014, pp. 2672–2680.   
[147] L. Schoneveld, “Semi-supervised learning with generative adversarial networks,” in Doctoral dissertation, Ph.D. Dissertation, 2017.   
[148] A. Radford, L. Metz, and S. Chintala, “Unsupervised representation learning with deep convolutional generative adversarial networks,” in ICLR, 2016.   
[149] J. T. Springenberg, “Unsupervised and semi-supervised learning with categorical generative adversarial networks,” in ICLR, 2016.   
[150] E. L. Denton, S. Gross, and R. Fergus, “Semi-supervised learning with context-conditional generative adversarial networks,” CoRR, vol. abs/1611.06430, 2016.   
[151] A. Odena, “Semi-supervised learning with generative adversarial networks,” CoRR, vol. abs/1606.01583, 2016.   
[152] T. Salimans, I. J. Goodfellow, W. Zaremba, V. Cheung, A. Radford, and X. Chen, “Improved techniques for training gans,” in NIPS, 2016, pp. 2226–2234.   
[153] Z. Dai, Z. Yang, F. Yang, W. W. Cohen, and R. Salakhutdinov, “Good semi-supervised learning that requires a bad GAN,” in NIPS, 2017, pp. 6510–6520.   
[154] G. Qi, L. Zhang, H. Hu, M. Edraki, J. Wang, and X. Hua, “Global versus localized generative adversarial nets,” in CVPR. IEEE Computer Society, 2018, pp. 1517–1525.   
[155] X. Wei, B. Gong, Z. Liu, W. Lu, and L. Wang, “Improving the improved training of wasserstein gans: A consistency term and its dual effect,” in ICLR. OpenReview.net, 2018.   
[156] M. Arjovsky, S. Chintala, and L. Bottou, “Wasserstein GAN,” CoRR, vol. abs/1701.07875, 2017.   
[157] I. Gulrajani, F. Ahmed, M. Arjovsky, V. Dumoulin, and A. C. Courville, “Improved training of wasserstein gans,” in NIPS, 2017, pp. 5767–5777.   
[158] J. Donahue, P. Kr¨ahenb ¨uhl, and T. Darrell, “Adversarial feature learning,” in ICLR. OpenReview.net, 2017.   
[159] V. Dumoulin, I. Belghazi, B. Poole, A. Lamb, M. Arjovsky, O. Mastropietro, and A. C. Courville, “Adversarially learned inference,” in ICLR. OpenReview.net, 2017.   
[160] A. Kumar, P. Sattigeri, and T. Fletcher, “Semi-supervised learning with gans: Manifold invariance with improved inference,” in NIPS, 2017, pp. 5534–5544.   
[161] C. Li, T. Xu, J. Zhu, and B. Zhang, “Triple generative adversarial nets,” in NIPS, 2017, pp. 4088–4098.   
[162] Z. Gan, L. Chen, W. Wang, Y. Pu, Y. Zhang, H. Liu, C. Li, and L. Carin, “Triangle generative adversarial networks,” in NIPS, 2017, pp. 5247–5256.   
[163] S. Wu, G. Deng, J. Li, R. Li, Z. Yu, and H. Wong, “Enhancing triplegan for semi-supervised conditional instance synthesis and classification,” in CVPR. Computer Vision Foundation / IEEE, 2019, pp. 10 091–10 100.   
[164] J. Dong and T. Lin, “Margingan: Adversarial training in semisupervised learning,” in NeurIPS, 2019, pp. 10 440–10 449.   
[165] Z. Deng, H. Zhang, X. Liang, L. Yang, S. Xu, J. Zhu, and E. P. Xing, “Structured generative adversarial networks,” in NIPS, 2017, pp. 3899–3909.   
[166] Y. Liu, G. Deng, X. Zeng, S. Wu, Z. Yu, and H.-S. Wong, “Regularizing discriminative capability of cgans for semi-supervised generative learning,” in CVPR, 2020.   
[167] S. Yun, D. Han, S. Chun, S. J. Oh, Y. Yoo, and J. Choe, “Cutmix: Regularization strategy to train strong classifiers with localizable features,” in ICCV. IEEE, 2019, pp. 6022–6031.   
[168] D. P. Kingma and M. Welling, “Auto-encoding variational bayes,” in ICLR, 2014.   
[169] D. J. Rezende, S. Mohamed, and D. Wierstra, “Stochastic backpropagation and approximate inference in deep generative models,” in ICML, ser. JMLR Workshop and Conference Proceedings, vol. 32. JMLR.org, 2014, pp. 1278–1286.   
[170] D. P. Kingma, S. Mohamed, D. J. Rezende, and M. Welling, “Semisupervised learning with deep generative models,” in NIPS, 2014, pp. 3581–3589.   
[171] L. Maaløe, C. K. Sønderby, S. K. Sønderby, and O. Winther, “Auxiliary deep generative models,” in ICML, ser. JMLR Workshop and Conference Proceedings, vol. 48. JMLR.org, 2016, pp. 1445– 1453.   
[172] M. E. Abbasnejad, A. R. Dick, and A. van den Hengel, “Infinite variational autoencoder for semi-supervised learning,” in CVPR. IEEE Computer Society, 2017, pp. 781–790.   
[173] S. Narayanaswamy, B. Paige, J. van de Meent, A. Desmaison, N. D. Goodman, P. Kohli, F. D. Wood, and P. H. S. Torr, “Learning disentangled representations with semi-supervised deep generative models,” in NIPS, 2017, pp. 5925–5935.   
[174] J. Schulman, N. Heess, T. Weber, and P. Abbeel, “Gradient estimation using stochastic computation graphs,” in NIPS, 2015, pp. 3528–3536.   
[175] Y. Li, Q. Pan, S. Wang, H. Peng, T. Yang, and E. Cambria, “Disentangled variational auto-encoder for semi-supervised learning,” Inf. Sci., vol. 482, pp. 73–85, 2019.   
[176] T. Joy, S. M. Schmon, P. H. S. Torr, N. Siddharth, and T. Rainforth, “Rethinking semi-supervised learning in vaes,” CoRR, vol. abs/2006.10102, 2020.   
[177] M. Belkin and P. Niyogi, “Laplacian eigenmaps and spectral techniques for embedding and clustering,” in NIPS. MIT Press, 2001, pp. 585–591.   
[178] Z. Ke, D. Wang, Q. Yan, J. S. J. Ren, and R. W. H. Lau, “Dual student: Breaking the limits of the teacher in semi-supervised learning,” in ICCV. IEEE, 2019, pp. 6727–6735.   
[179] M. Pezeshki, L. Fan, P. Brakel, A. C. Courville, and Y. Bengio, “Deconstructing the ladder network architecture,” in ICML, ser. JMLR Workshop and Conference Proceedings, vol. 48. JMLR.org, 2016, pp. 2368–2376.   
[180] T. Miyato, S. Maeda, M. Koyama, and S. Ishii, “Virtual adversarial training: A regularization method for supervised and semi-supervised learning,” IEEE Trans. Pattern Anal. Mach. Intell., vol. 41, no. 8, pp. 1979–1993, 2019.   
[181] P. Izmailov, D. Podoprikhin, T. Garipov, D. P. Vetrov, and A. G. Wilson, “Averaging weights leads to wider optima and better generalization,” in UAI. AUAI Press, 2018, pp. 876–885.   
[182] B. Athiwaratkun, M. Finzi, P. Izmailov, and A. G. Wilson, “There are many consistent explanations of unlabeled data: Why you should average,” in ICLR. OpenReview.net, 2019.   
[183] S. Park, J. Park, S. Shin, and I. Moon, “Adversarial dropout for supervised and semi-supervised learning,” in AAAI. AAAI Press, 2018, pp. 3917–3924.   
[184] Q. Xie, Z. Dai, E. H. Hovy, T. Luong, and Q. Le, “Unsupervised data augmentation for consistency training,” in NeurIPS, 2020.   
[185] E. D. Cubuk, B. Zoph, D. Mane, V. Vasudevan, and Q. V. Le, “Autoaugment: Learning augmentation strategies from data,” in CVPR. Computer Vision Foundation / IEEE, 2019, pp. 113–123.   
[186] E. D. Cubuk, B. Zoph, J. Shlens, and Q. V. Le, “Randaugment: Practical data augmentation with no separate search,” CoRR, vol. abs/1909.13719, 2019.   
[187] R. Sennrich, B. Haddow, and A. Birch, “Improving neural machine translation models with monolingual data,” in ACL. The Association for Computer Linguistics, 2016.   
[188] S. Edunov, M. Ott, M. Auli, and D. Grangier, “Understanding back-translation at scale,” in EMNLP. Association for Computational Linguistics, 2018, pp. 489–500.   
[189] A. Iscen, G. Tolias, Y. Avrithis, and O. Chum, “Label propagation for deep semi-supervised learning,” in CVPR. Computer Vision Foundation / IEEE, 2019, pp. 5070–5079.   
[190] P. Chen, T. Ma, X. Qin, W. Xu, and S. Zhou, “Data-efficient semisupervised learning by reliable edge mining,” in CVPR. IEEE, 2020, pp. 9189–9198.   
[191] S. Li, B. Liu, D. Chen, Q. Chu, L. Yuan, and N. Yu, “Density-aware graph for deep semi-supervised visual recognition,” in CVPR. IEEE, 2020, pp. 13 397–13 406.   
[192] B. Perozzi, R. Al-Rfou, and S. Skiena, “Deepwalk: online learning of social representations,” in KDD. ACM, 2014, pp. 701–710.   
[193] J. Tang, M. Qu, M. Wang, M. Zhang, J. Yan, and Q. Mei, “LINE: large-scale information network embedding,” in WWW. ACM, 2015, pp. 1067–1077.   
[194] A. Grover and J. Leskovec, “node2vec: Scalable feature learning for networks,” in KDD. ACM, 2016, pp. 855–864.   
[195] D. Wang, P. Cui, and W. Zhu, “Structural deep network embedding,” in KDD. ACM, 2016, pp. 1225–1234.   
[196] M. Belkin and P. Niyogi, “Laplacian eigenmaps and spectral techniques for embedding and clustering,” in NIPS. MIT Press, 2001, pp. 585–591.   
[197] S. Cao, W. Lu, and Q. Xu, “Deep neural networks for learning graph representations,” in AAAI. AAAI Press, 2016, pp. 1145– 1152.   
[198] M. Ou, P. Cui, J. Pei, Z. Zhang, and W. Zhu, “Asymmetric transitivity preserving graph embedding,” in KDD. ACM, 2016, pp. 1105–1114.   
[199] T. N. Kipf and M. Welling, “Variational graph auto-encoders,” CoRR, vol. abs/1611.07308, 2016.   
[200] —, “Semi-supervised classification with graph convolutional networks,” in ICLR. OpenReview.net, 2017.   
[201] J. Gilmer, S. S. Schoenholz, P. F. Riley, O. Vinyals, and G. E. Dahl, “Neural message passing for quantum chemistry,” in ICML, ser. Proceedings of Machine Learning Research, vol. 70. PMLR, 2017, pp. 1263–1272.   
[202] F. Scarselli, M. Gori, A. C. Tsoi, M. Hagenbuchner, and G. Monfardini, “The graph neural network model,” IEEE Trans. Neural Networks, vol. 20, no. 1, pp. 61–80, 2009.   
[203] H. Wang, C. Zhou, X. Chen, J. Wu, S. Pan, and J. Wang, “Graph stochastic neural networks for semi-supervised learning,” in NeurIPS, 2020.   
[204] W. Feng, J. Zhang, Y. Dong, Y. Han, H. Luan, Q. Xu, Q. Yang, E. Kharlamov, and J. Tang, “Graph random neural networks for semi-supervised learning on graphs,” in NeurIPS, 2020.   
[205] Q. Li, Z. Han, and X. Wu, “Deeper insights into graph convolutional networks for semi-supervised learning,” in AAAI. AAAI Press, 2018, pp. 3538–3545.   
[206] R. Liao, M. Brockschmidt, D. Tarlow, A. L. Gaunt, R. Urtasun, and R. S. Zemel, “Graph partition neural networks for semisupervised classification,” in ICLR. OpenReview.net, 2018.   
[207] Y. Zhang, S. Pal, M. Coates, and D. ¨Ustebay, “Bayesian graph convolutional neural networks for semi-supervised classification,” in AAAI. AAAI Press, 2019, pp. 5829–5836.   
[208] S. Vashishth, P. Yadav, M. Bhandari, and P. P. Talukdar, “Confidence-based graph convolutional networks for semisupervised learning,” in AISTATS, ser. Proceedings of Machine Learning Research, vol. 89. PMLR, 2019, pp. 1792–1801.   
[209] C. Zhuang and Q. Ma, “Dual graph convolutional networks for graph-based semi-supervised classification,” in WWW. ACM, 2018, pp. 499–508.   
[210] F. Hu, Y. Zhu, S. Wu, L. Wang, and T. Tan, “Hierarchical graph convolutional networks for semi-supervised node classification,” in IJCAI. ijcai.org, 2019, pp. 4532–4539.   
[211] D. Bahdanau, K. Cho, and Y. Bengio, “Neural machine translation by jointly learning to align and translate,” in ICLR, 2015.   
[212] W. L. Hamilton, Z. Ying, and J. Leskovec, “Inductive representation learning on large graphs,” in NIPS, 2017, pp. 1024–1034.   
[213] Y. Li, D. Tarlow, M. Brockschmidt, and R. S. Zemel, “Gated graph sequence neural networks,” in ICLR, 2016.   
[214] J. Chung, C¸ . Gu¨ l¸cehre, K. Cho, and Y. Bengio, “Empirical evaluation of gated recurrent neural networks on sequence modeling,” CoRR, vol. abs/1412.3555, 2014.   
[215] D. Selsam, M. Lamm, B. B ¨unz, P. Liang, L. de Moura, and D. L. Dill, “Learning a SAT solver from single-bit supervision,” in ICLR. OpenReview.net, 2019.   
[216] Z. Zhou and M. Li, “Semi-supervised learning by disagreement,” Knowl. Inf. Syst., vol. 24, no. 3, pp. 415–439, 2010.   
[217] S. Qiao, W. Shen, Z. Zhang, B. Wang, and A. L. Yuille, “Deep cotraining for semi-supervised image recognition,” in ECCV, ser. Lecture Notes in Computer Science, vol. 11219. Springer, 2018, pp. 142–159.   
[218] Y. Cheng, X. Zhao, R. Cai, Z. Li, K. Huang, and Y. Rui, “Semisupervised multimodal deep learning for RGB-D object recognition,” in IJCAI. IJCAI/AAAI Press, 2016, pp. 3345–3351.   
[219] R. Xia, C. Wang, X. Dai, and T. Li, “Co-training for semisupervised sentiment classification based on dual-view bags-ofwords representation,” in ACL. The Association for Computer Linguistics, 2015, pp. 1054–1063.   
[220] D. Chen, W. Wang, W. Gao, and Z. Zhou, “Tri-net for semisupervised deep learning,” in IJCAI. ijcai.org, 2018, pp. 2014– 2020.   
[221] Z. Zhou and M. Li, “Tri-training: Exploiting unlabeled data using three classifiers,” IEEE Trans. Knowl. Data Eng., vol. 17, no. 11, pp. 1529–1541, 2005.   
[222] L. Breiman, “Randomizing outputs to increase prediction accuracy,” Mach. Learn., vol. 40, no. 3, pp. 229–242, 2000.   
[223] Y. Grandvalet and Y. Bengio, “Semi-supervised learning by entropy minimization,” in NIPS, 2004, pp. 529–536.   
[224] D.-H. Lee, “Pseudo-label: The simple and efficient semisupervised learning method for deep neural networks,” in Workshop on challenges in representation learning, ICML, vol. 3, no. 2, 2013.   
[225] Q. Xie, M. Luong, E. H. Hovy, and Q. V. Le, “Self-training with noisy student improves imagenet classification,” in CVPR. IEEE, 2020, pp. 10 684–10 695.   
[226] G. E. Hinton, O. Vinyals, and J. Dean, “Distilling the knowledge in a neural network,” CoRR, vol. abs/1503.02531, 2015.   
[227] M. Tan and Q. V. Le, “Efficientnet: Rethinking model scaling for convolutional neural networks,” in ICML, ser. Proceedings of Machine Learning Research, vol. 97. PMLR, 2019, pp. 6105–6114.   
[228] E. D. Cubuk, B. Zoph, J. Shlens, and Q. V. Le, “Randaugment: Practical automated data augmentation with a reduced search space,” in CVPR Workshops. IEEE, 2020, pp. 3008–3017.   
[229] L. Beyer, X. Zhai, A. Oliver, and A. Kolesnikov, “S4L: selfsupervised semi-supervised learning,” in ICCV. IEEE, 2019, pp. 1476–1485.   
[230] A. Kolesnikov, X. Zhai, and L. Beyer, “Revisiting self-supervised visual representation learning,” in CVPR. Computer Vision Foundation / IEEE, 2019, pp. 1920–1929.   
[231] S. Gidaris, P. Singh, and N. Komodakis, “Unsupervised representation learning by predicting image rotations,” in ICLR. OpenReview.net, 2018.   
[232] A. Dosovitskiy, J. T. Springenberg, M. A. Riedmiller, and T. Brox, “Discriminative unsupervised feature learning with convolutional neural networks,” in NIPS, 2014, pp. 766–774.   
[233] A. Dosovitskiy, P. Fischer, J. T. Springenberg, M. A. Riedmiller, and T. Brox, “Discriminative unsupervised feature learning with exemplar convolutional neural networks,” IEEE Trans. Pattern Anal. Mach. Intell., vol. 38, no. 9, pp. 1734–1747, 2016.   
[234] C. Szegedy, W. Liu, Y. Jia, P. Sermanet, S. E. Reed, D. Anguelov, D. Erhan, V. Vanhoucke, and A. Rabinovich, “Going deeper with convolutions,” in CVPR. IEEE Computer Society, 2015, pp. 1–9.   
[235] A. Hermans, L. Beyer, and B. Leibe, “In defense of the triplet loss for person re-identification,” CoRR, vol. abs/1703.07737, 2017.   
[236] H. Pham, Q. Xie, Z. Dai, and Q. V. Le, “Meta pseudo labels,” CoRR, vol. abs/2003.10580, 2020.   
[237] X. Wang, D. Kihara, J. Luo, and G. Qi, “Enaet: A self-trained framework for semi-supervised and supervised learning with ensemble transformations,” IEEE Trans. Image Process., vol. 30, pp. 1639–1647, 2021.   
[238] L. Zhang, G. Qi, L. Wang, and J. Luo, “AET vs. AED: unsupervised representation learning by auto-encoding transformations rather than data,” in CVPR. Computer Vision Foundation / IEEE, 2019.   
[239] T. Chen, S. Kornblith, K. Swersky, M. Norouzi, and G. E. Hinton, “Big self-supervised models are strong semi-supervised learners,” in NeurIPS, 2020.   
[240] T. Chen, S. Kornblith, M. Norouzi, and G. E. Hinton, “A simple framework for contrastive learning of visual representations,” in ICML, ser. Proceedings of Machine Learning Research, vol. 119. PMLR, 2020, pp. 1597–1607.   
[241] H. Zhang, M. Cisse´, Y. N. Dauphin, and D. Lopez-Paz, “mixup: Beyond empirical risk minimization,” in ICLR. OpenReview.net, 2018.   
[242] K. Sohn, D. Berthelot, N. Carlini, Z. Zhang, H. Zhang, C. Raffel, E. D. Cubuk, A. Kurakin, and C. Li, “Fixmatch: Simplifying semi-supervised learning with consistency and confidence,” in NeurIPS, 2020.   
[243] T. Devries and G. W. Taylor, “Improved regularization of convolutional neural networks with cutout,” CoRR, vol. abs/1708.04552, 2017.   
[244] Z. Ren, R. A. Yeh, and A. G. Schwing, “Not all unlabeled data are equal: Learning to weight data in semi-supervised learning,” in NeurIPS, 2020.   
[245] B. Zoph, G. Ghiasi, T. Lin, Y. Cui, H. Liu, E. D. Cubuk, and Q. Le, “Rethinking pre-training and self-training,” in NeurIPS, 2020.   
[246] A. Ghosh and A. H. Thiery, “On data-augmentation and consistency-based semi-supervised learning,” in ICLR. OpenReview.net, 2021.   
[247] Z. Hu, X. Ma, Z. Liu, E. H. Hovy, and E. P. Xing, “Harnessing deep neural networks with logic rules,” in ACL. The Association for Computer Linguistics, 2016.   
[248] Y. Tang, J. Wang, X. Wang, B. Gao, E. Dellandre´a, R. J. Gaizauskas, and L. Chen, “Visual and semantic knowledge transfer for large scale semi-supervised object detection,” IEEE Trans. Pattern Anal. Mach. Intell., vol. 40, no. 12, pp. 3045–3058, 2018.   
[249] M. Qi, Y. Wang, J. Qin, and A. Li, “KE-GAN: knowledge embedded generative adversarial networks for semi-supervised scene parsing,” in CVPR. Computer Vision Foundation / IEEE, 2019, pp. 5237–5246.   
[250] S. Yu, X. Yang, and W. Zhang, “PKGCN: prior knowledge enhanced graph convolutional network for graph-based semisupervised learning,” Int. J. Machine Learning & Cybernetics, vol. 10, no. 11, pp. 3115–3127, 2019.   
[251] P. Swarup, D. Chakrabarty, A. Sapru, H. Tulsiani, H. Arsikere, and S. Garimella, “Knowledge distillation and data selection for semi-supervised learning in CTC acoustic models,” CoRR, vol. abs/2008.03923, 2020.   
[252] S. E. Reed, H. Lee, D. Anguelov, C. Szegedy, D. Erhan, and A. Rabinovich, “Training deep neural networks on noisy labels with bootstrapping,” in ICLR, 2015.   
[253] Z. Lu and L. Wang, “Noise-robust semi-supervised learning via fast sparse coding,” Pattern Recognit., vol. 48, no. 2, pp. 605–612, 2015.   
[254] B. Han, Q. Yao, X. Yu, G. Niu, M. Xu, W. Hu, I. W. Tsang, and M. Sugiyama, “Co-teaching: Robust training of deep neural 8n5et36w–o8r5k4s6 .with extremely noisy labels,” in NeurIPS, 2018, pp.   
[255] J. M. Johnson and T. M. Khoshgoftaar, “Survey on deep learning with class imbalance,” J. Big Data, vol. 6, p. 27, 2019.   
[256] J. Kim, Y. Hur, S. Park, E. Yang, S. J. Hwang, and J. Shin, “Distribution aligning refinery of pseudo-label for imbalanced semi-supervised learning,” in NeurIPS, 2020.   
[257] J. Deng and J. Yu, “A simple graph-based semi-supervised learning approach for imbalanced classification,” Pattern Recognit., vol. 118, p. 108026, 2021.   
[258] Z. Zhong, L. Zheng, G. Kang, S. Li, and Y. Yang, “Random erasing data augmentation,” in AAAI. AAAI Press, 2020, pp. 13 001– 13 008.   
[259] K. K. Singh, H. Yu, A. Sarmasi, G. Pradeep, and Y. J. Lee, “Hideand-seek: A data augmentation technique for weakly-supervised localization and beyond,” CoRR, vol. abs/1811.02545, 2018.   
[260] P. Chen, S. Liu, H. Zhao, and J. Jia, “Gridmask data augmentation,” CoRR, vol. abs/2001.04086, 2020.   
[261] A. Singh, R. D. Nowak, and X. Zhu, “Unlabeled data: Now it helps, now it doesn’t,” in NIPS. Curran Associates, Inc., 2008, pp. 1513–1520.   
[262] T. Yang and C. E. Priebe, “The effect of model misspecification on semi-supervised classification,” IEEE Trans. Pattern Anal. Mach. Intell., vol. 33, no. 10, pp. 2093–2103, 2011.   
[263] N. V. Chawla and G. I. Karakoulas, “Learning from labeled and unlabeled data: An empirical study across techniques and domains,” J. Artif. Intell. Res., vol. 23, pp. 331–366, 2005.  